#ifndef GLOBALS_H
#define GLOBALS_H

#include "staticfilecontroller.h"

using namespace stefanfrings;
extern StaticFileController* staticFileController;

#endif // GLOBALS_H
