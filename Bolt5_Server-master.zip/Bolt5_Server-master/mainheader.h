#ifndef MAINHEADER
#define MAINHEADER

#ifdef USE_LORA
#include "modules/LoraWAN/LoraDemodulator.h"
#include "modules/LoraWAN/decoder_impl.h"
#endif

#endif // MAINHEADER

