#include <QCoreApplication>
#include <QTcpServer>
#include "logger.h"
#include "reciever.h"
#include "fifofer.h"
#include "udp_clients.h"

void sig_int_handler(int signo) {
    //DEFiusLogger::close();
    exit(0);
}

int main(int argc, char *argv[]) {
    signal(SIGINT, sig_int_handler);
    signal(SIGTERM, sig_int_handler);

    QCoreApplication a(argc, argv);

    /*
    DEFiusLogger::initStartTime();
    DEFiusLogger::setStaticLogFile("log.txt");
    DEFiusLogger() << "Start server\n";
    DEFiusLogger() << "Start server\n";
    DEFiusLogger::save();
    */

    UDP_Clients::init();

    Reciever* rec;
    if (argc == 4) {
        int port = std::stoi(argv[0]);
        FIFOfer::init(port);

        sprintf(FIFOfer::buff, "123");
        FIFOfer::writeTo();

        rec = new Reciever(port, argv[1], argv[2], argv[3]);
    }
    else
        rec = new Reciever();

    return a.exec();
}
