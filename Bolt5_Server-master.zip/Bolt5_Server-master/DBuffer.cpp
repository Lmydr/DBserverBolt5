#include "DBuffer.h"
#include <time.h>

DBuffer::DBuffer() {
    ptr = 0;
    vec.reserve(10);
}

DBuffer::~DBuffer() {
    vec.clear();
}

void* DBuffer::data() {
    return vec.data();
}

void* DBuffer::dataToWork() {
    return vec.data() + ptr;
}

int DBuffer::size() {
    return vec.size();
}

void DBuffer::insert(gr_complex* data, int size) {
    printf("insert complex\n");
    vec.insert(vec.end(), data, data + size/2);
}

void DBuffer::insert(int16_t* data, int size) {
    //printf("DB s\n");
    int lastIndex = vec.size();
    vec.resize(lastIndex + size);
    for (int i=0; i < (size/2); i++) {
	float iC = data[i*2],
	      qC = data[i*2 + 1];

	float div = 1024.0 * 16.0 - 1.0;
    div /= max;

    //iC /= div;
    //qC /= div;

	vec[lastIndex + i].real(iC);
	vec[lastIndex + i].imag(qC);
	//gr_complex tmp(iC, qC);
	//vec.push_back(tmp);
    }
    //printf("DB f\n");
    //for (int i=0; i<8; i++) {
//	printf("%0.5f %0.5f ", vec[i].real(), vec[i].imag());
//    }
    //printf("\n");
}

bool DBuffer::isAvailable() {
    return ((int64_t)vec.size() - (int64_t)ptr) > ASIZE;
}

void DBuffer::clean() {
    vec.erase(vec.begin(), vec.begin() + ptr);
    ptr = 0;
}
