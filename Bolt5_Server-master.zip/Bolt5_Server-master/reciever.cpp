﻿#include "reciever.h"
#include <fstream>

//#include "windows.h"

//#define IGNORE_CLIENT
//#define fakedata

void process_stat(double& vm_usage, double& resident_set, double& cpu_usage);

Reciever::Reciever()
{
    qDebug() << "qDebug() on";
    server = new QTcpServer();
    dashboardServer = new QTcpServer();
    udp = new QUdpSocket(this);
    folder = "outputs/";

#ifndef IGNORE_CLIENT
    connect(server, SIGNAL(newConnection()), this, SLOT(onNewConnection()));
    //connect(server, SIGNAL(disconnected()), this, SLOT(onDisconnection()));
#endif
    std::fstream settings("settings.txt");
    if (!settings) {
        std::cout << "settings.txt not found\n";
        return;
    }

    OpenUNB_init();

    settings >> port;
    settings >> dashboard_port;
    settings >> ttnName;
    settings >> ttnKey;

    qDebug() << "Port: " << port;

    if (!server->listen(QHostAddress::Any, port)) {
        qDebug() <<  QObject::tr("Unable to start the server: %1.").arg(server->errorString());
        serverStatus = ERROR;
    }
    else {
        serverStatus = WAITING;

        if (!udp->bind(QHostAddress::Any, 16202)) {
            qDebug() <<  QObject::tr("Unable to start the UDP server: %1.").arg(udp->errorString());
        }
        else {
            connect(udp, SIGNAL(readyRead()), SLOT(getUDPData()));
        }
        address = new QHostAddress();
#ifdef IGNORE_CLIENT
        client = new Client(server->nextPendingConnection());
        client->mdec.loraInit(ttnName, ttnKey);
        client->generateTable();
        client->init10Mbuffers();
#endif
        if (!dashboardServer->listen(QHostAddress::Any, 12012)) {
            qDebug() <<  QObject::tr("Unable to start the dashboard server: %1.").arg(server->errorString());
        }
        else {
            connect(dashboardServer, SIGNAL(newConnection()), this, SLOT(onDashboradConnected()));
        }

        std::cout << "Start server\n";

        initTTN(ttnName, ttnKey);

        dataPSecTimer = new QTimer();
        QObject::connect(dataPSecTimer, SIGNAL(timeout()), this, SLOT(timeout()));
        dataPSecTimer->setInterval(1000/UPDATE_P_SEC);
        dataPSecTimer->start();

        cleanerTimer = new QTimer();
        QObject::connect(cleanerTimer , SIGNAL(timeout()), this, SLOT(AFKCleaner()));
        cleanerTimer->setInterval(500);
        cleanerTimer->start();

        averageSpeedTimer = new QTimer();
        QObject::connect(averageSpeedTimer , SIGNAL(timeout()), this, SLOT(saveAverageSpeed()));
        averageSpeedTimer->setInterval(60*1000);
        averageSpeedTimer->start();


        //loopFromFile("lora.data");
#ifdef fakedata+
        int datasize = 1024000;
        unsigned char* faked = new unsigned char[datasize];
        for (int i=0; i<datasize; i++) {
            faked[i] = i;
        }
        onNewConnection();
        //while (1) {
            updateLimeData(faked, datasize);
        //    usleep(1000000);
        //}
        qDebug() << "Done";
#endif
    }

}

Reciever::Reciever(int p, std::string ttnN, std::string ttnK, std::string f) {
    port = p;
    ttnName = ttnN;
    ttnKey = ttnK;
    folder = f;

    qDebug() << "Port: " << port;


    server = new QTcpServer();
    udp = new QUdpSocket(this);

    if (!server->listen(QHostAddress::Any, port)) {
        qDebug() <<  QObject::tr("Unable to start the server: %1.").arg(server->errorString());
    }
    else {
        if (!udp->bind(QHostAddress::Any, 16202)) {
            qDebug() <<  QObject::tr("Unable to start the UDP server: %1.").arg(udp->errorString());
        }
        else {
            connect(udp, SIGNAL(readyRead()), SLOT(getUDPData()));
        }
        address = new QHostAddress();
#ifdef IGNORE_CLIENT
        client = new Client(server->nextPendingConnection());
        client->mdec.loraInit(ttnName, ttnKey);
        client->generateTable();
        client->init10Mbuffers();
#endif
        std::cout << "Start server\n";

        //logpath = QString(folder.data()) + "out.txt";
        //append = false;

        dataPSecTimer = new QTimer();
        QObject::connect(dataPSecTimer, SIGNAL(timeout()), this, SLOT(timeout()));
        dataPSecTimer->setInterval(1000/UPDATE_P_SEC);
        dataPSecTimer->start();

        cleanerTimer = new QTimer();
        QObject::connect(cleanerTimer , SIGNAL(timeout()), this, SLOT(AFKCleaner()));
        cleanerTimer->setInterval(500);
        cleanerTimer->start();

        averageSpeedTimer = new QTimer();
        QObject::connect(averageSpeedTimer , SIGNAL(timeout()), this, SLOT(saveAverageSpeed()));
        averageSpeedTimer->setInterval(60*1000);
        averageSpeedTimer->start();


        //loopFromFile("lora.data");
#ifdef fakedata
        int datasize = 1024000;
        unsigned char* faked = new unsigned char[datasize];
        for (int i=0; i<datasize; i++) {
            faked[i] = i;
        }
        onNewConnection();
        //while (1) {
            updateLimeData(faked, datasize);
        //    usleep(1000000);
        //}
        qDebug() << "Done";
#endif
    }
}

void Reciever::initTTN(std::string name, std::string key) {
    //ttn = new TTNGatewayConnector(name, key);
}

void Reciever::onNewConnection() {
    std::cout << "New connection!\n";

    serverStatus = RUNING;

    if (client) {
        delete client;
        connections--;
    }

    client = new Client(server->nextPendingConnection());//, ttn);

#ifdef USE_LORA
    for (int ch = 0; ch < CHANNELS; ch++)
        client->mdec[ch].loraInit(client->ttn);
#endif
    connect(client->soc, SIGNAL(readyRead()), this, SLOT(getFirstData()));

    //for (int i=0; i< THREADS; i++)
    connect(client->demodulator, SIGNAL(messages_ready(NBFiDemodulator*)), this, SLOT(set_messages(NBFiDemodulator*)), Qt::QueuedConnection);


    QFile outFile(QString(folder.data()) + "speed_list.txt");
    if (!outFile.open(QIODevice::Append | QIODevice::WriteOnly))
        return;
    QTextStream out(&outFile);

    out << "New connection" << endl;
    outFile.close();
}

void Reciever::onDashboradConnected() {
    std::cout << "Dashboard connected!\n";

    dashboardClient = dashboardServer->nextPendingConnection();
    connect(dashboardClient, SIGNAL(readyRead()), this, SLOT(getRequest()));
}

void Reciever::getFirstData() {
    QByteArray array = ((QTcpSocket*)sender())->readAll();
    QString name = QString::fromLatin1(array);

    disconnect(client->soc, SIGNAL(readyRead()), this, SLOT(getFirstData()));

    if (name == "RTLSDR") {
        std::cout << "RTLSDR\n" ;
        device = RTLSDR;
    }
    else if (name == "LimeSDR") {
        std::cout << "LimeSDR\n" ;
        device = LimeSDR;
#ifdef USE_LORA
        client->generateTable();
        client->init10Mbuffers();
#endif
    }
    else {
        std::cout << "GNU Radio\n" ;
        device = GNURadio;
#ifdef USE_LORA
        client->generateTable();
        client->init10Mbuffers();
#endif
    }

    connect(client->soc, SIGNAL(readyRead()), this, SLOT(getData()));
}

#define TEST 0
bool boo1 = false;

void Reciever::getUDPData() {
    QByteArray array;
    array.resize(udp->pendingDatagramSize());
    udp->readDatagram(array.data(), array.size(), address);

    //qDebug() << "Data size = " << array.size() << "\tindex = " << client->buffIndex;

    float* data = (float*)array.data();
    int size = array.size()/sizeof(float);
    //qDebug() << size;
#if TEST == 1
    client->sb.insertToFB(data, size);
    client->udp1233->send((char*)client->sb.getFB_f( ), 1024*sizeof(float)*2);

    //if (client->sb.size10MF_grc() > FRAMELEN10M) {
        //qDebug() << "Evt";
        client->sb.getSubChannelsFromFB();

    if (client->sb.size125K_grc() > 1024) {
        client->udp1234->send((char*)client->sb.getFB_f(0), 1024*sizeof(float)*2);
        //client->udp1235->send((char*)client->sb.getFB_f(1), 1024*sizeof(float)*2);
            //client->sb.erase_f(1024);
        client->sb.erase_f(client->sb.size125K_f());

    }

#elif TEST == 2
    for (int i=0; i<size; i++) {
        client->buff10M_F[client->buffIndex++] = data[i];


        if (client->buffIndex == FRAMELEN10M) {
            client->buffIndex = 0;

            client->fft();
            //client->getSubChannelsFramesFrom10M();
            //client->filtrChannel(79);

            //client->udp1233->send((char*)client->buff10M_F, 1024*sizeof(float));
            client->udp1233->send((char*)client->subBuffers[79], 1024*sizeof(float)*2);
            client->udp1234->send((char*)client->subBuffers[0], 1024*sizeof(float)*2);
            client->udp1235->send((char*)client->subBuffers[1], 1024*sizeof(float)*2);
        }
    }
#elif TEST == 3
    client->sb.insertToFB(data, size);
    client->udp1233->send((char*)client->sb.getFB_f( ), 1024*sizeof(float)*2);
    client->sb.FBToBB();
    client->sb.cleanFB();
    client->sb.getSubChannelsFromBB();
    if (client->sb.size125K_grc() > 1024) {
        //qDebug() << "Evt!";
        //for (int i=0; i<50; i++);
            client->udp1234->send((char*)client->sb.getFB_f(0), 1024*sizeof(float)*2);
        client->sb.erase_grc(client->sb.size125K_grc());
    }
    //client->sb.cleanFB();
#elif TEST == 4
    float tmpb[1024*2];

    client->sb->insertToFB(data, size);
    //client->sb->FBToBB();
    //client->sb->cleanFB();
    //client->sb->BBToFB();
    //client->sb->cleanBB();
    //client->sb->getSubChannels250KFromFB();
    client->sb->getSubChannels125KFromFB();
    if (client->sb->size125K_grc() > 1024*2) {
        /*
        for (int i=0; i<1024; i++) {
            tmpb[i*2] = client->sb->get250KB_grc(0)[i*2 + boo1].real();
            tmpb[i*2+1] = client->sb->get250KB_grc(0)[i*2 + boo1].imag();
        }
        //client->udp1234->send((char*)tmpb, 1024*sizeof(float)*2);

        for (int i=0; i<1024; i++) {
            tmpb[i*2] = client->sb->get250KB_grc(1)[i*2 + boo1].real();
            tmpb[i*2+1] = client->sb->get250KB_grc(1)[i*2 + boo1].imag();
        }
        //client->udp1233->send((char*)tmpb, 1024*sizeof(float)*2);

        for (int i=0; i<1024; i++) {
            tmpb[i*2] = client->sb->get250KB_grc(2)[i*2 + boo1].real();
            tmpb[i*2+1] = client->sb->get250KB_grc(2)[i*2 + boo1].imag();
        }
        */
        //client->udp1235->send((char*)tmpb, 1024*sizeof(float)*2);
        //client->udp1234->send((char*)client->sb->get250KB_f(0), 1024*sizeof(float)*2);
        //client->udp1233->send((char*)client->sb->get250KB_f(1), 1024*sizeof(float)*2);
        client->udp1235->send((char*)client->sb->get125KB_f(1), 1024*sizeof(float)*2);
        boo1 = client->sb->size250K_grc()%2 ? !boo1 : boo1;

        client->sb->clean250KB();
        client->sb->clean125KB();
    }
#endif
    usleep(5000);
}

void Reciever::getRequest() {
    QByteArray array = ((QTcpSocket*)sender())->readAll();
    char ans[32];

    for (int i=0; i<array.size(); i++) {
    ans[0] = array[i];

    switch (array.data()[i]) {
        case REQ_ECHO: {
            //char ans[] = {REQ_ECHO};
            ans[1] = REQ_ECHO;
            dashboardClient->write(ans, 2);
        }
        break;

        case REQ_TEST: {
            char ans[] = "Hi mom!";
            dashboardClient->write(ans, sizeof(ans));
        }
        break;

        case REQ_SPEED: {
            memcpy(&ans[1], &lastAvgSpeed, sizeof(lastAvgSpeed));
            dashboardClient->write(ans, sizeof(lastAvgSpeed) + 1);
        }
        break;

        case REQ_CPU: {
            //double vm_usage, resident_set, cpu;
            //process_stat(vm_usage, resident_set, cpu);
            memcpy(&ans[1], &lastCPU, sizeof(lastCPU));
            dashboardClient->write(ans, sizeof(lastCPU) + 1);
        }
        break;

	case REQ_MSG_CNT: {
            //double vm_usage, resident_set, cpu;
            //process_stat(vm_usage, resident_set, cpu);
            memcpy(&ans[1], &msgCount, sizeof(msgCount));
            dashboardClient->write(ans, sizeof(msgCount) + 1);
        }
        break;

        case REQ_MEM: {
            double vm_usage, resident_set, cpu;
            process_stat(vm_usage, resident_set, cpu);
            memcpy(&ans[1], &vm_usage, sizeof(vm_usage));
            dashboardClient->write(ans, sizeof(vm_usage) + 1);
        }
        break;

        case REQ_ALL_DATA: {
            double vm_usage, resident_set, cpu;
            process_stat(vm_usage, resident_set, cpu);

            dashboard_data_t data;
            data.speed = lastAvgSpeed;
            data.CPU = lastCPU;
            data.mem = vm_usage;
            data.dec_count = msgCount;

            dashboardClient->write((char*)&data, sizeof(data));
        }
        break;
    }

    }
}

void Reciever::getData() {
    QByteArray array = ((QTcpSocket*)sender())->readAll();
    dataPSec += array.size();
    //qDebug() << "Data size = " << array.size();// << "\tindex = " << buffIndex;

#ifdef USE_LORA
    if (device == GNURadio) {
        if (client->buffIndex + array.size() < FRAMELEN10M*sizeof(gr_complex)) {
            memcpy((char*)client->buff10M_F + client->buffIndex, array.data(), array.size());
            client->buffIndex += array.size();
        }
        else {

            int delta = FRAMELEN10M*sizeof(gr_complex) - client->buffIndex;
            memcpy((char*)client->buff10M_F + client->buffIndex, array.data(), delta);
            updateGNURData(client->buff10M_F, FRAMELEN10M);
            memcpy((char*)client->buff10M_F, array.data() + delta, array.size() - delta);
            client->buffIndex = array.size() - delta;
        }


        return;
    }


    if (device == LimeSDR) {
        updateLimeData((uint8_t*)array.data(), array.size());
        return;
    }
#endif

    dataPSec += array.size();
    for (int i=0; i<array.size(); i++) {

        if (memcmp(array.data() + i, "STRT", 4) == 0) {
            //qDebug() << "STRT";
            client->buffIndex = 0;
            i+=3;
        }
        else
            if (memcmp(array.data() + i, "FNSH", 4) == 0) {
                //qDebug() << "FNSH";
                float fmax = *(float*)(array.data() + i - 5);
                bool sign = *(float*)(array.data() + i - 1);
                client->max = fmax;
                //printf("%f %d\n", fmax, sign);
                i+=3;
                updateRTLData();

            }
            else {
                if (client->buffIndex < sizeof(client->buff))
                    client->buff[client->buffIndex++] = array.data()[i];

            }
    }

}

void Reciever::updateRTLData() {
#ifdef deflateX2
    uLongf size1 = *((uint32_t*)client->buff);

    if (size1 > sizeof(client->buff)) {
        //qDebug() << "size1 = " << size1;
        //qDebug() << "Error pkg(";
        DEFiusLogger() << "Error packet size1\n";
        return;
    }

    uLongf size2 = *((uint32_t*)(client->buff + sizeof(uint32_t) + *((uint32_t*)client->buff)));

    if (size2 > FRAMELEN*4) {
        DEFiusLogger() << "Error packet size1\n";
        //qDebug() << "dsize2 = " << size2 - FRAMELEN*2 ;
        //qDebug() << "Error pkg(";
        return;
    }

    char buff1[FRAMELEN*4];
    char buff2[FRAMELEN*4];
    uLongf uncompressSize = FRAMELEN*2;

    uLongf totalSize = 0;
    if (uncompress((Bytef*)buff1, &uncompressSize, (Bytef*)(client->buff + sizeof(uint32_t)), size1) != 0) {
        DEFiusLogger() << "Error uncompress1\n";
        //qDebug() << "Err1";
        return;
    }
    totalSize += uncompressSize;
    if (uncompress((Bytef*)buff2, &uncompressSize, (Bytef*)(client->buff + 2*sizeof(uint32_t) + size1), size2) != 0) {
        DEFiusLogger() << "Error uncompress2\n";
        //qDebug() << "Err2";
        return;
    }

    totalSize += uncompressSize;

    //float* minmax = (float*)(client->buff + 2 * sizeof(uint32_t) + size1 + size2);
    //printf("%X %X\n", client->buff[2 * sizeof(uint32_t) + size1 + size2 - 1], client->buff[2 * sizeof(uint32_t) + size1 + size2 - 2]);

#ifdef USE_LORA
    if (client->mdec[0].buff.max < minmax[1])
        client->mdec[0].buff.max = minmax[1];

    if (client->mdec[0].buff.min > minmax[0])
        client->mdec[0].buff.min = minmax[0];
#endif
    for (int i=0; i<totalSize; i+=2) {
        client->buff[i] = buff1[i/2];
        client->buff[i+1] = buff2[i/2];
    }

    float mul = 1024.0*16.0 - 1.0;

    //client->mdec[0].buff.insert((int16_t*)client->buff, FRAMELEN*2);
    //client->mdec[0].start();
    float* dataF = new float[totalSize];
    uint16_t* sh = (uint16_t*)client->buff;

    for (int i=0; i < FRAMELEN*2; i++) {
        dataF[i] = ((float)((int16_t*)client->buff)[i]) / mul * client->max;//minmax[1];
    }

    //std::cout << mul * minmax[1] << std::endl;
    //std::cout << minmax[0] << "  " << minmax[1] << "  " << ((char*)minmax - client->buff) << std::endl;

    avgDataRate += totalSize/2/2;
    client->demodulator->work((qint16*)client->buff, totalSize/2);
    OpenUNB_add_iq((fftwf_complex*)dataF, FRAMELEN);
    UDP_Clients::udp1233->send((char*)dataF, 1024*8);
    //client->udp1233->send((char*)dataF, 1024*8);

    delete [] dataF;

    //client->udp->send((char*)client->mdec.buff.data(), 1024*sizeof(float));

#else
    uLongf size = *((uint32_t*)buff);
    unsigned char unComBuff[FRAMELEN*4];
    uLongf uncompressSize = FRAMELEN*4;
    uncompress((Bytef*)unComBuff, &uncompressSize, (Bytef*)(buff + sizeof(uint32_t)), size);
    rec->getFromTCP((qint16*)unComBuff, FRAMELEN);
#endif

}

int a=0, b=0;

#ifdef USE_LORA
void Reciever::updateLimeData(uint8_t* arr, int size) {
    QTime timer;
    timer.start();

    client->sb->insertToBB(arr, size);

    //client->sb->addNoiseToBB(0);

    if (client->sb->size10MB_grc() > 1024*100) {
        int lsize = client->sb->size10MB_grc();

        client->sb->BBToFB(1024);
        client->udp1234->send((char*)client->sb->getFB_fftwfc(), 1024*sizeof(float)*2);
        client->sb->cleanFB();

        client->sb->getSubChannels250KFromBB();

        //qDebug() << timer.elapsed();
        if (client->sb->size250K_grc() > 1024) {
            //client->sb->addNoise(0);
            client->udp1235->send((char*)client->sb->get250KB_f(0), 1024*sizeof(float)*2);
            //client->udp1235->send((char*)client->sb->noiseArray, 1024*sizeof(float)*2);

            for (int ch = 0; ch < CHANNELS-16; ch++) {
                client->mdec[ch].run();
            }
        }
        //qDebug() << timer.elapsed();
        a += timer.elapsed();
        b += lsize/10000;
        //qDebug() << timer.elapsed() << "ms (expected time:" << lsize/10000 << "ms" << (float)timer.elapsed()/(lsize/10000)*100 << "%)";
        //qDebug() << a*100/b << "%";
    }
}

void Reciever::updateGNURData(gr_complex* arr, int size) {
    //if (size%4)
        //qDebug() << "ooops!";
    client->sb->insertToFB(arr, size);
    //client->sb->addNoiseToFB(1.0);
    //client->udp1233->send((char*)client->sb->getFB_f( ), 1024*sizeof(float)*2);

    //client->udp1234->send((char*)client->sb->getFB_f( ), 1024*sizeof(float)*2);
    //client->udp1234->send((char*)client->sb->noise, 1024*sizeof(float)*2);
    //client->sb->cleanFB();


    
    //client->sb->FBToBB();
//    client->sb->cleanFB();
//    client->sb->BBToFB();
//    client->udp1234->send((char*)client->sb->getFB_f( ), 1024*sizeof(float)*2);
//    client->sb->cleanFB();

    client->sb->getSubChannels250KFromFB();

    if (client->sb->size250K_grc() > 1024) {
        //client->udp1235->send((char*)client->sb->get250KB_grc(0), 1024*sizeof(float)*2);
        //client->mdec[0].buff.insert(client->sb->get250KB_grc(0), client->sb->size250K_grc());
        client->mdec[0].start();
        client->sb->clean250KB();
    }
}

#endif

void Reciever::loopFromFile(QString file) {
    QFile f(file);

    if (f.open(QIODevice::ReadOnly))
        qDebug() << "File size:" << f.size();
    else {
        qDebug() << "File error";
        return;
    }

    onNewConnection();

    QByteArray ba = f.readAll();
    gr_complex* grc = (gr_complex*)ba.data();
    unsigned long long size = f.size()/sizeof(gr_complex);

    //for (int i=0; i< 10; i++)
    //    qDebug() << grc[i].imag() << grc[i].real();
    //for (unsigned long long i=0; i<size; i += 1024*1024) {
        //qDebug() << i << "/" << size << "(" << i*100/size << "% )";
#ifdef USE_LORA
    client->sb->insertToFB(grc, size);
    client->sb->addNoiseToFB(0.01);
    client->sb->FBToBB();
    //client->sb->cleanFB();

    client->sb->getSubChannels250KFromBB();

    for (int ch = 0; ch < CHANNELS-16; ch++) {
        client->mdec[ch].run();
    }
#endif
    //}

    qDebug() << "Done";
}

void Reciever::timeout() {
    //DEFiusLogger::save();

    totalByteResieved += dataPSec;
    averageSpeed += dataPSec;
    averageSpeedCount++;

    lastAvgSpeed = averageSpeed/averageSpeedCount;
    //FIFOfer::readFrom();
    //std::string msg(FIFOfer::buff);
    //printf("1\n");

/*
    QFile outFile(logpath);
    outFile.open(QIODevice::WriteOnly);
    QTextStream ts(&outFile);
    ts << "";
    outFile.close();

    QTextStream out(stdout);

    totalByteResieved += dataPSec;
    averageSpeed += dataPSec;
    averageSpeedCount++;

*/
    double vm_usage, resident_set, cpu;
    process_stat(vm_usage, resident_set, cpu);
    lastCPU = cpu;

#ifdef USE_OUTPUT
    system("clear");
    qDebug() << "qDebug() on";
    std::cout << "Server date: " << QDateTime::currentDateTime().toString("dd.MM.yyyy hh:mm:ss.zzz").toStdString() << std::endl;
    std::cout << "Port: " << port << std::endl;
    std::cout << "TTN gateway: " << QString::fromStdString(ttnName).toStdString() << std::endl;
    std::cout << "TTN key: " << QString::fromStdString(ttnKey).toStdString() << std::endl;
    std::cout << "Connections: " << connections << std::endl;
    std::cout << "Input stream speed: " << dataPSec/UPDATE_P_SEC << " Bytes/s" << std::endl;
    std::cout << "Average speed: " << averageSpeed/averageSpeedCount << " Bytes/s" << std::endl;
    std::cout << "Data rate: " << avgDataRate/UPDATE_P_SEC << " Samples/s" << std::endl;

    std::cout << "Number of batches: " << batches << std::endl;
    std::cout << "Number of decoded messages: " << msgCount << std::endl;
    if (client) {
        std::cout << "Device: ";
        switch (device) {
            case RTLSDR:
                std::cout << "RTLSDR" << std::endl;
                break;
            case LimeSDR:
                std::cout << "LimeSDR" << std::endl;
                break;
            case GNURadio:
                std::cout << "GNURadio" << std::endl;
                break;

        }

#ifdef USE_LORA
        std::cout << "Correlation:\t0.5\t0.6\t0.7\t0.8\t0.9" << std::endl;
        std::cout << "\t\t" << client->mdec->loradec->corr50 << "\t" << client->mdec->loradec->corr60 << "\t" << client->mdec->loradec->corr70 << "\t" << client->mdec->loradec->corr80 << "\t" << client->mdec->loradec->corr90 << std::endl;
#endif
        std::cout << "IP: " << client->soc->peerAddress().toString().toStdString() << std::endl;
    }
    std::cout << "RX: " << totalByteResieved << " bytes" << std::endl << std::endl;

    std::cout << "Using mem: " << vm_usage << " KB " << std::endl;
    std::cout << "CPU: " << cpu << "%" << std::endl << std::endl;


    std::cout << "Dashboard server status: ";

    if (dashboardServer->isListening()) {
        if (dashboardClient) {
            if (dashboardClient->state() == QAbstractSocket::ConnectedState)
                std::cout << "client connected" << std::endl;
            else
                std::cout << "client not connected" << std::endl;
        } else {
            std::cout << "client not connected" << std::endl;
        }
    } else {
        std::cout << "not work" << std::endl;
    }
#endif

    avgDataRate = 0;
    dataPSec = 0;
}

bool LessThan(const message_point* m1, const message_point *m2)
{
    return (m1->time < m2->time);
}

void Reciever::set_messages(NBFiDemodulator *dem) {
    
    batches++;

    QFile outFile("decoded.txt");
    if (!outFile.open(QIODevice::Append | QIODevice::WriteOnly))
        return;

    QTextStream out(&outFile);

    static QList<message_point*> prev;

    QList<message_point*>::iterator i;
    QList<message_point*>::iterator j;


    qSort(dem->filtered_list.begin(), dem->filtered_list.end(), LessThan);

    //qDebug() << " " << dem->filtered_list.size() << " MSG";

    int count = 0;

    for (i = dem->filtered_list.begin(); i != dem->filtered_list.end(); i++)
    {
        count++;


        for (j = prev.begin(); j != prev.end(); j++)
        {
            if (*(*i) == *(*j)) break;
        }
        if (j != prev.end())
        {
            message_point* m = (*j);
            uint filter_interval = 1500;
            switch(dem->symRate())
            {
                case 50:
                    filter_interval = 6000;
                break;
                case 400:
                    filter_interval = 750;
                break;
            }
            if(abs((*i)->time.msecsTo((*j)->time)) < filter_interval)
            {
                if(m) delete m;
                prev.removeOne((*j));
                m = NULL;
                continue;
            }
            if(m) delete m;
            prev.removeOne((*j));
            m = NULL;


        }

        out << "#" << dem->batch_id << " ";
        out << (*i)->time.toString("dd.MM.yyyy hh:mm:ss.zzz") << " ";


        out << "RID=" << QString::number((*i)->ID, 16).toUpper() << " ";
        out << "PLD:";
        for (int k = 0; k < 8; k++)
        {
            out << QString::number((*i)->PAYLOAD[k], 16).toUpper() << " ";
        }
        if((*i)->FLAGS&0b10000000) out << 'S';
        if((*i)->FLAGS&0b1000000) out << 'A';
        if((*i)->FLAGS&0b100000) out << 'M';
        out << " IT=" << (unsigned char)((*i)->FLAGS&0x1f) << " ";
        switch((*i)->TYPE)
        {
            case MESSAGE_C:
                out  <<  "PROTC ";
            break;
            case MESSAGE_D:
                out  <<  "PROTD ";
                out  <<  "CRC8:" << QString::number((*i)->CRC8_D, 16).toUpper() << " ";
            break;
        }

        out  << dem->symRate() << "BPS ";

        switch((*i)->demod_method)
        {
        case DEMOD_CRC:
            out <<  "DEMOD=CRC" << " ";
            break;
        case DEMOD_1_2:
            out <<  "DEMOD=1/2" << " ";
            break;
        case DEMOD_1_3:
            out <<  "DEMOD=1/3" << " ";
            break;
        }

        out << "RSSI=" << QString::number((*i)->RSSI, 'q', 1) << " ";
        out <<  "MINRSSI=" << QString::number((*i)->MIN_RSSI, 'q', 1) << " ";
        out <<  "MAXRSSI=" << QString::number((*i)->MAX_RSSI, 'q', 1) << " ";

        out << "SNR=" << QString::number((*i)->SNR, 'q', 1) << " ";

        out << "FREQ=" << (*i)->FREQ << " ";
        out << "ROT=" << (*i)->rotation << " ";
        out << "ERR=" << (*i)->err_num << " ";
        out << "COPIES=" << (*i)->num_of_copies << "(" << (*i)->num_of_copies_1_2 << "\n";

        out << "PKG Size = " << sizeof((*i)->packet) << "\n";///////////////////////////////////
        for (int k =0; k<sizeof((*i)->packet); k++) {
            out << QString::number((*i)->packet[k], 16) << " ";
        }

        out << "\n";

        int freq_expect;

        if((*i)->FREQ < uplink_freq)
        {
            if((*i)->TYPE == MESSAGE_C) out << "Expected FREQ = " << (freq_expect = (uplink_freq - 25000) + ((((*i)->ID)%226)*100)) << "\n";
            else out << "Expected FREQ = " << (freq_expect = (uplink_freq - 25000) + ((((*i)->ID + (*i)->CRC8_D)%226)*100)) << "\n";


        }
        else
        {
            if((*i)->TYPE == MESSAGE_C) out << "Expected FREQ = " << (freq_expect = (uplink_freq - 25000) + ((((*i)->ID)%226)*100) + 27500) << "\n";
            else out << "Expected FREQ = " << (freq_expect = (uplink_freq - 25000) + ((((*i)->ID + (*i)->CRC8_D)%226)*100) + 27500) << "\n";
        }



        // std::cout << "Delta = " << (signed)(*i) ->FREQ - freq_expect << "\n";
        //std::cout << "DL freq = " << (uint)(downlink_freq + ((((*i)->ID)%276)*363) +  (((double)downlink_freq)/uplink_freq)*((signed)(*i) ->FREQ - freq_expect)) << "\n";
        //std::cout << "DL freq = " << (uint)(downlink_freq + (((*i)->P_CRC%(275+1)) * 363) +  (((double)downlink_freq)/uplink_freq)*((signed)(*i) ->FREQ - freq_expect)) << "\n";
    }

    //if (count != 0)
        //printf("%d msg\n", count);

    msgCount += count;

    outFile.close();
    dem->clear_all();
}

void Reciever::AFKCleaner() {
    QFile outFile("speed list.txt");
    if (!outFile.open(QIODevice::Append | QIODevice::WriteOnly))
        return;
    QTextStream out(&outFile);

    if (client) {
        if (client->soc->state() != QAbstractSocket::ConnectedState) {
            disconnect(client->soc, SIGNAL(readyRead()), this, SLOT(getFirstData()));
            disconnect(client->soc, SIGNAL(readyRead()), this, SLOT(getData()));
            delete client;
            client = nullptr;
            connections--;
        }
    }
    /*
    for (int i=0; i<IDs.size(); i++) {
        if (clients[IDs[i]]->soc->state() != QAbstractSocket::ConnectedState) {
            connections--;
            out << "Connection lost. Connections: " << connections << std::endl;
            delete clients[IDs[i]];
            clients.remove(IDs[i]);
            IDs.erase(IDs.begin() + i);
        }
    }
    */
    outFile.close();
}

void Reciever::onDisconnection() {

}

void Reciever::saveAverageSpeed() {
    QFile outFile("speed list.txt");
    if (!outFile.open(QIODevice::Append | QIODevice::WriteOnly))
        return;

    QTextStream out(&outFile);

    QDateTime time = QDateTime::currentDateTime();

    lastAvgSpeed = averageSpeed / 60;
    out << time.toString("dd.MM.yyyy hh:mm:ss") << "\t" << lastAvgSpeed << endl;

    averageSpeed = 0;
    averageSpeedCount = 0;
}

double last_total_time = 0.0;
double last_time = 0.0;

void process_stat(double& vm_usage, double& resident_set, double& cpu_usage) {
    using std::ios_base;
    using std::ifstream;
    using std::string;

    vm_usage     = 0.0;
    resident_set = 0.0;
    cpu_usage    = 0.0;

    ifstream stat_stream("/proc/self/stat",ios_base::in);
    ifstream start_time_stream("/proc/uptime",ios_base::in);

    string pid, comm, state, ppid, pgrp, session, tty_nr;
    string tpgid, flags, minflt, cminflt, majflt, cmajflt;
    string cutime, cstime, priority, nice;
    string O, itrealvalue;

    unsigned long vsize, utime, stime, uptime, starttime;
    long rss, hz;

    start_time_stream >> uptime;

    stat_stream >> pid >> comm >> state >> ppid >> pgrp >> session >> tty_nr
               >> tpgid >> flags >> minflt >> cminflt >> majflt >> cmajflt
               >> utime >> stime >> cutime >> cstime >> priority >> nice
               >> O >> itrealvalue >> starttime >> vsize >> rss;

    double total_time = utime + stime;
    hz = sysconf(_SC_CLK_TCK);

    double seconds = uptime - ((double)starttime / (double)hz);
    cpu_usage = 100 * (((total_time - last_total_time) / hz) / (seconds - last_time));

    last_total_time = total_time;
    last_time = seconds;

    stat_stream.close();
    start_time_stream.close();

    long page_size_kb = sysconf(_SC_PAGE_SIZE) / 1024;
    vm_usage     = vsize / 1024.0;
    resident_set = rss * page_size_kb;
}
