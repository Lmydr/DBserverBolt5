#!bin/bash

sudo apt install gcc g++ make qt5-qmake qt5-default libfftw3-dev libfftw3-3 libprotobuf-c-dev libliquid-dev libvolk2-dev git cmake libprotobuf-dev

#mkdir libsForBolt5
#cd libsForBolt5/

#git clone https://github.com/eclipse/paho.mqtt.embedded-c
#cd paho.mqtt.embedded-c/
#mkdir build
#cd build/
#cmake ..
#make -j4
#sudo make install
#cd ../..

#git clone https://github.com/TheThingsNetwork/ttn-gateway-connector
#cd ttn-gateway-connector/

