#ifndef DEFINES_H
#define DEFINES_H


#define THREADS 1

#define SEND_RABBIT_NO_ACK

//#define _WINDOWS_
#define _LINUX_

#ifdef _WINDOWS_
    #define SDR
    #define FFTW
#endif


#ifdef _LINUX_
    #define ALSA
    #define ASIC
    //#define GPUFFT
    #define FFTW
    //#define BS3
    #define USE_SERVER
    #define SPECTRUM_SERVER
    #define NBFI_HEARTBEATS

    #endif


#define DEFAULT_UL_FREQ 868800000
#define DEFAULT_DL_FREQ 446000000



#endif // DEFINES_H

