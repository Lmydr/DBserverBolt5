#ifndef DECODER_H
#define DECODER_H

#include <thread>
#include <mutex>
#include <unistd.h>
#include <queue>
#include <iostream>
#include <fstream>
#include <cstring>

#include "preamblepoint.h"
#include "pcscl_noperm.h"
#include "VectorHelper.h"
#include "udp_clients.h"

class OpenUNBDecoder
{
public:
    OpenUNBDecoder(int symLen);

    void pushPreablePoint(PreamblePoint* pp);
    int size();
    void setCallback(void (*clb_f)(uint8_t* data, size_t size));
private:
    std::mutex mut;
    std::queue<PreamblePoint*> preablePointVector;
    std::thread* th;
    int symlen;

    void (*clb_f)(uint8_t* data, size_t size) = nullptr;

    bool isRun;

    void run();

};

#endif // DECODER_H
