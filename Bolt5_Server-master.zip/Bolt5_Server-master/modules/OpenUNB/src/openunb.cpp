#include "modules/OpenUNB/include/openunb.h"
#include "modules/OpenUNB/privateInclude/demodulator.h"

OpenUNBDemodulator* dem;

int OpenUNB_init() {
    dem = new OpenUNBDemodulator(125000);
    return 0;
}

int OpenUNB_uninit() {
    delete dem;
    return 0;
}

void OpenUNB_add_iq(fftwf_complex* data, size_t size) {
    dem->addIQ(data, size);
}

void OpenUNB_add_iq(std::complex<float>* data, size_t size) {
    dem->addIQ(data, size);
}

void OpenUNB_set_clb(void (*clb_f)(uint8_t* data, size_t size)) {
    dem->setCallback(clb_f);
}
