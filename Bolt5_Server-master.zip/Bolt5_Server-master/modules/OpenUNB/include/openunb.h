#ifndef OPENUNB_H
#define OPENUNB_H

#include <fftw3.h>
#include <complex>
#include <stdint.h>

int OpenUNB_init();
int OpenUNB_uninit();
void OpenUNB_add_iq(fftwf_complex* data, size_t size);
void OpenUNB_add_iq(std::complex<float>* data, size_t size);
void OpenUNB_set_clb(void (*clb_f)(uint8_t* data, size_t size));


#endif // OPENUNB_H
