/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   DBuffer.h
 * Author: khramtsovviktor
 *
 * Created on 21 мая 2019 г., 14:56
 */



#ifndef DBUFFER_H
#define DBUFFER_H

#ifdef USE_LORA

#include <vector>
#include <complex>

typedef std::complex<float>			gr_complex;

#define ASIZE 1024*16
//#define gr_complex char

class DBuffer {
public:
    int ptr;
    
    DBuffer();
    DBuffer(std::vector<gr_complex>*);
    virtual ~DBuffer();
    
    gr_complex operator[] (int index);
    void* data();
    void* dataToWork();
    bool isAvailable();
    int size();
    void insert(int16_t* data, int size);
    void insert(gr_complex* data, int size);
    void clean();

    void setVec(std::vector<gr_complex>*);

    float min, max;
private:
    std::vector<gr_complex>* vec;
};

#endif

#endif /* DBUFFER_H */
