/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   mainDecoder.cpp
 * Author: DEF
 * 
 * Created on 29 мая 2019 г., 15:16
 */

#ifdef USE_LORA

#include "modules/LoraWAN/LoraDemodulator.h"

mainDecoder::mainDecoder(){

    //ttn = new TTNGatewayConnector("defius", "ttn-account-v2.ep0mludPutERt34LGYkCw_0gaIwG2S19o9z_S2f8WaEryAOtbg_qbIfqfxQg8A2PR9TagDFH3q6g764bo32xAA");
}

mainDecoder::~mainDecoder() {
    delete loradec;
}
/*
void mainDecoder::loraInit(std::string name, std::string key) {
    printf("LoraInit()\n");
    ttn = new TTNGatewayConnector(name, key);
    loradec = new gr::lora::decoder_impl(250000,125000,7,false,4,true,false,false);
    loradec->freq = freq;
}

void mainDecoder::loraTestInit() {
    ttn = new TTNGatewayConnector("defius", "ttn-account-v2.ep0mludPutERt34LGYkCw_0gaIwG2S19o9z_S2f8WaEryAOtbg_qbIfqfxQg8A2PR9TagDFH3q6g764bo32xAA");
    loradec = new gr::lora::decoder_impl(125000,125000,7,false,4,true,false,false);
    loradec->freq = freq;
}
*/
void mainDecoder::loraInit(TTNGatewayConnector* t) {
    ttn = t;
    loradec = new gr::lora::decoder_impl(125000,125000,7,false,4,true,false,false);
    loradec->freq = freq;
}

void mainDecoder::run() {
    //printf("in1 %d\n", buff.size());
    while (buff.isAvailable()) {
        buff.ptr += loradec->work((gr_complex*)buff.dataToWork());
    }
    buff.clean();
    //printf("in2 %d\n", buff.size());
    if (loradec->msg) {
        loradec-> msg = false;
        printf("MSG!!! Freq = %fMHz\n", freq/1000000.0);

        if (loradec->lastMsgSize > 5) {
            printf("Send to TTN\n");

            ttn->send(loradec->lastMsg+3, loradec->lastMsgSize - 5);

            time_t now = time(0);
            char* dt = ctime(&now);

            std::ofstream ofs ("msg.txt", std::ofstream::out | std::ofstream::app);
            ofs << "Time: " << dt << std::endl;
            for (int i=0; i<loradec->lastMsgSize; i++)
                ofs << std::hex << (int)loradec->lastMsg[i] << " ";
            ofs << std::endl;

            ofs.close();
        }
    }
    //printf("in f\n");
}

void mainDecoder::msgDecoded_cb(char *data, int size) {
    ttn->send(data, size);
}
#endif
