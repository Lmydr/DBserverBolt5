#ifndef EL_SIN_GENERATOR_H
#define EL_SIN_GENERATOR_H

#include <cmath>

class EllipticSinGenerator {
public:
    explicit EllipticSinGenerator(float in_k);
    const EllipticSinGenerator& operator=(const EllipticSinGenerator& inGen);
    EllipticSinGenerator(){};
    void generate();
    inline float getSin() {return m_sin;};
    inline float getCos() {return m_cos;};
private:
    void initialize(float in_k);

    float m_z1;
    float m_z2;
    float m_k1;
    float m_k2;
    float m_sin;
    float m_cos;
    float m_corr_coef;
    int m_n_corr;
};


#endif // EL_SIN_GENERATOR_H
