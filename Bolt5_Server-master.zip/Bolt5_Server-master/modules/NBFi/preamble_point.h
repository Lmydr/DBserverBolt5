#ifndef PREAMBLE_POINT_H
#define PREAMBLE_POINT_H


class preamble_point
{
public:
    preamble_point(long x, long y, int table, long long corr, int pre, int err);

    int x_coord;
    int y_coord;
    int table_no;
    long long corr_sign;
    int pre_sign;
    //float RSSI;
	int err_num;

};

#endif // PREAMBLE_POINT_H
