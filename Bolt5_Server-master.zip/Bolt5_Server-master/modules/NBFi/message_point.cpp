#include "message_point.h"
#include <cstdio>


message_point::message_point()
{
    TYPE = MESSAGE_C;
	demod_method = 0;
    calculated = 0;
    tmp_for_aver_freq = 1;
    num_of_copies = 1;
    num_of_copies_1_2 = 0;
    processed = 0;
    emited = 0;

}

const message_point& message_point::operator=(const message_point& mes)
{
    TYPE = mes.TYPE;
    ID = mes.ID;
    FLAGS = mes.FLAGS;
    RSSI = mes.RSSI;
    MIN_RSSI = mes.MIN_RSSI;
    MAX_RSSI = mes.MAX_RSSI;
    SNR = mes.SNR;
    CRC8_D = mes.CRC8_D;
    MIN_SNR = mes.MIN_SNR;
    MAX_SNR = mes.MAX_SNR;
    NOISE = mes.NOISE;
    FREQ = mes.FREQ;
    time = mes.time;
    demod_method = mes.demod_method;
    bitrate = mes.bitrate;
    batch_id = mes.batch_id;
    err_num = mes.err_num;
	for(int i = 0; i < 8; i++) PAYLOAD[i] = mes.PAYLOAD[i];
	if (demod_method == DEMOD_1_3) preamble_1_3 = new preamble_point(0, 0, 0, 0, 0, 0);
	return *this;
}

bool message_point::operator==(message_point &a)
{
    if((TYPE == a.TYPE)&&(ID == a.ID)&&(FLAGS == a.FLAGS))
    {
        if((TYPE == MESSAGE_D) && (CRC8_D != a.CRC8_D)) return false;
        for(int i = 0; i < 8; i++)
            if(PAYLOAD[i] != a.PAYLOAD[i]) return false;
        return true;
    }
    else return false;
}

bool message_point::operator<(message_point &a)
{
	return time < a.time;
}

bool message_point::operator>(message_point &a)
{
	return time > a.time;
}


message_point::~message_point()
{

    if(demod_method == DEMOD_1_3) delete preamble_1_3;
}

QString message_point::getPayload()
{
	char hexStr[256] = { 0 };
	int hexPos = 0;

	for (int i = 0; i < 8; i++) {
		sprintf(hexStr + hexPos, "%02X", (unsigned char)PAYLOAD[i]);
		hexPos += 2;
	}
	return hexStr;
}
