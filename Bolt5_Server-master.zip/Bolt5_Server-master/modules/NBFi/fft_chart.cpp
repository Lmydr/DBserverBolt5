#include "fft_chart.h"

fft_chart::fft_chart(long len)
{
    data = new float[len];
    data_len = len;
}

fft_chart::~fft_chart()
{
    delete data;
}

float* fft_chart::getdata()
{
    return data;
}

void fft_chart::setdata(float *indata)
{
    for(long i=0; i < data_len; i++) data[i] = indata[i];
}

long fft_chart::size()
{
     return data_len;
}

void fft_chart::resize(long dlen)
{
    data_len = dlen;
    delete data;
    data = new float[dlen];
}

long fft_chart::getlen()
{
    return data_len;
}

void fft_chart::setTime(const QTime &t)
{
    ch_time = t;
}

QTime fft_chart::time()
{

    return ch_time;
}
