
#include "zigzag.h"

#include <stdlib.h>
#include <cmath>
#include <algorithm>
#include <QString>
#include <QDebug>

using namespace std;

#define length 128


inline float abs_f(float a)
{
    if(a>0) return a;
    return -a;
}

void zigzag_decoder_soft_var_len(float* d_in, int* d_out/* ,float* d_out_soft*/)
{
	
    float* data_bits;
    float* data_bits_buf;
    data_bits     = (float*) calloc(length,sizeof(float));
    data_bits_buf = (float*) calloc(length,sizeof(float));
    float* parity_bits;

    float* delta;
	
	parity_bits = (float*) calloc(2*length,sizeof(float));
	delta       = (float*) calloc(4*length, sizeof(float));

    int i;
    for (i = 0; i < length; i = i + 1)
    {
        data_bits[i] = d_in[i];
    }

    for (i = 0; i < 2*length; i = i + 1)
    {
        parity_bits[i] = d_in[i + length];
    }
    //qDebug() << "\n";
    for (i = 0; i < 16; i = i + 1)
        zigzag_decoder_iter_soft_var_len(data_bits, parity_bits, i%4, delta);

    for (i = 0; i < length; i = i + 1)
    {
        //d_out_soft[i] = data_bits[i];
        if (data_bits[i] < 0)
            d_out[i] = 1;
        else
            d_out[i] = 0;
    }
    free(data_bits);
    free(data_bits_buf);
    free(parity_bits);
    free(delta);
}

void zigzag_decoder_iter_soft_var_len(float* data, float* parity,short stage, float* delta)
{

    int main_cycle_len = length/2;
	float *forward_p     = /*buf; */(float*) calloc(main_cycle_len + 1,sizeof(float));
    float backward_p;
    float fb_p_full_fixed = 1e+20F;
    forward_p[0] = 1e+20F;
    backward_p = parity[stage*main_cycle_len + main_cycle_len - 1];
    int i;
    for (i = 1; i < main_cycle_len + 1; i = i + 1)
    {
        //if (i<5)
            //qDebug() << " << " << i << ") " << data[get_data_addr_soft_var_len(i-1 + length*stage,stage)] - delta[stage * length  + i - 1];
        fb_p_full_fixed = parity[stage * main_cycle_len  + i - 1] +
        min_abs_prod_soft_var_len( fb_p_full_fixed,
                                   data[get_data_addr_soft_var_len(i-1 + length*stage,stage)] - delta[stage * length  + i - 1],
                                   data[get_data_addr_soft_var_len(i -1 + main_cycle_len + length*stage,stage)] - delta[stage * length + main_cycle_len + i - 1]);
        forward_p[i] = fb_p_full_fixed;
    }

    for (i = 0; i < main_cycle_len; i = i + 1)
    {
        float d1,d2,d_fw;
        float min_val, min_val_2, d_min_val;
        int min_pos;
        int sign_full;
        int sign_bit[2];
        sign_full = 0;
        float delta0_new, delta1_new;
        float new_val_1;
        float new_val_2;
        int addr1, addr2;
        float delta1,delta2;
        addr1 = get_data_addr_soft_var_len((main_cycle_len -1) - i + length*stage,stage);
        addr2 = get_data_addr_soft_var_len((main_cycle_len -1) - i + main_cycle_len + length*stage,stage);
        delta1 = delta[stage * length + (main_cycle_len -1) - i];
        delta2 = delta[stage * length + (main_cycle_len -1) - i + main_cycle_len];
        d1 = data[addr1] - delta1;
        d2 = data[addr2] - delta2;
        if (d1 >= 0)
        {
            sign_bit[0] = 0;
        }
        else
        {
            sign_bit[0] = 1;
            sign_full+=1;
        }

        if (d2 >= 0)
        {
                sign_bit[1] = 0;
        }
        else
        {
                sign_bit[1] = 1;
                sign_full+=1;
        }
        if (abs_f(d1) <= abs_f(d2))
        {
                min_val = abs_f(d1);
                min_val_2 = abs_f(d2);
                min_pos = 0;
        }
        else
        {
                min_val = abs_f(d2);
                min_val_2 = abs_f(d1);
                min_pos = 1;
        }
        if (backward_p < 0)
                sign_full+=1;
        if (abs_f(backward_p) < min_val)
        {
                min_val_2 = min_val;
                min_val   = abs_f(backward_p);
                min_pos   = 2;
        }
        else if (abs_f(backward_p) < min_val_2)
        {
                min_val_2 = abs_f(backward_p);
        }

        if ((sign_full % 2) == 1)
                d_min_val = -min_val;
        else
                d_min_val = min_val;

        backward_p = parity[stage*main_cycle_len + (main_cycle_len - 1) - i -1] + d_min_val;
        d_fw = forward_p[(main_cycle_len - 1)-i];

        if (d_fw < 0)
            sign_full+=1;

        if (abs_f(d_fw) < min_val)
        {
            min_val_2 = min_val;
            min_val   = abs_f(d_fw);
            min_pos   = 3;
        }
        else if (abs_f(d_fw) < min_val_2)
        {
            min_val_2 = abs_f(d_fw);
        }

        sign_bit[0] = (sign_bit[0] + sign_full) % 2;
        sign_bit[1] = (sign_bit[1] + sign_full) % 2;

        if (min_pos == 0)
            if (sign_bit[0] == 0)
                delta0_new =  min_val_2;
            else
                delta0_new = -min_val_2;

        else
            if (sign_bit[0] == 0)
                delta0_new =  min_val;
            else
                delta0_new = -min_val;

        if (min_pos == 1)
            if (sign_bit[1] == 0)
                delta1_new =  min_val_2;
            else
                delta1_new = -min_val_2;
        else
            if (sign_bit[1] == 0)
                delta1_new =  min_val;
            else
                delta1_new = -min_val;

        delta0_new = delta0_new * 0.75;
        delta1_new = delta1_new * 0.75;
        new_val_1 = d1 + delta0_new;
        new_val_2 = d2 + delta1_new;
        data[addr1] = new_val_1;
        data[addr2] = new_val_2;
        delta[(main_cycle_len -1) - i + length*stage] = new_val_1 - d1;
        delta[(main_cycle_len -1) - i + main_cycle_len + length*stage] =  new_val_2 - d2;
    }
    free(forward_p);
}

float min_abs_prod_soft_var_len(float a1, float a2, float a3)
{
    short sign_bit;
    float a_min;

    sign_bit = (a1*a2*a3) < 0;
    a_min = std::min(abs_f(a1),abs_f(a2));
    a_min = std::min(abs_f(a3), a_min);

    if (sign_bit == 1)
        return -a_min;
    else
        return a_min;
}



int get_data_addr_soft_var_len(int addr_in, short stage)
{

const int int0[498] = {6,95,108,14,122,51,137,155,80,109,77,88,130,163,86,69,35,23,42,142,0,38,67,91,
        136,97,44,161,121,89,102,78,132,60,24,148,164,107,87,120,8,56,124,139,11,71,125,4,127,39,143,30,126,
        79,93,134,50,31,19,61,103,16,73,37,160,68,3,116,21,133,28,36,84,65,118,58,26,72,156,111,165,20,149,
        158,43,17,145,45,135,47,32,41,83,15,159,147,34,46,112,99,138,2,74,92,157,140,55,117,57,151,131,70,9,
        82,33,25,115,98,64,18,113,12,128,53,114,81,13,146,62,1,129,40,100,29,119,154,85,49,76,110,63,48,59,
        152,52,153,5,94,162,150,105,90,27,106,141,101,144,96,66,22,104,7,123,75,10,54,
        99,127,12,106,90,62,15,132,14,139,110,154,79,158,67,49,80,118,37,121,35,142,97,
        23,13,72,134,112,144,2,143,85,21,5,47,119,109,150,114,74,103,24,155,83,25,162,95,136,146,1,149,43,8,
        73,55,159,91,122,96,145,111,33,161,45,31,6,129,11,135,101,115,68,102,64,100,41,29,16,63,53,77,69,4,
        92,123,10,98,30,38,81,137,128,75,48,125,152,93,22,58,131,44,61,3,70,57,65,51,26,126,157,107,0,153,71,
        105,86,60,138,94,82,28,141,54,120,140,108,17,36,130,46,7,148,160,52,164,156,32,20,56,124,39,133,66,
        87,27,89,104,34,42,19,50,88,163,151,117,9,147,76,113,84,40,116,18,165,59,78,
        89,112,7,65,102,88,49,87,13,143,133,44,27,62,26,142,110,136,36,103,14,140,64,
        12,158,15,150,159,59,113,104,21,77,46,157,68,38,124,47,115,58,90,149,94,141,66,85,18,43,155,111,57,
        101,125,30,51,80,67,107,93,54,3,78,97,50,120,24,71,144,74,9,40,29,105,41,98,163,114,10,134,122,1,91,
        135,100,84,32,162,61,153,116,23,70,152,106,121,17,53,73,5,75,154,123,156,45,118,52,92,127,117,129,
        42,28,2,39,108,8,69,48,86,161,55,6,35,137,99,83,164,81,165,145,0,34,95,138,79,128,63,151,131,76,31,
        11,132,148,130,60,19,56,33,72,126,160,96,20,139,25,4,146,16,37,109,82,119,147,22};


const int int1[384] = {104,52,43,96,31,7,71,78,58,37,93,25,125,85,42,111,6,95,72,117,27,51,63,84,91,35,120,26,
        97,45,110,70,1,28,86,114,53,67,12,127,40,101,73,94,115,61,20,126,3,46,92,116,9,56,87,77,109,44,65,54,
        100,118,2,34,21,41,76,14,69,124,90,18,103,48,113,36,0,81,13,62,24,38,105,68,15,75,88,50,122,29,83,102,
        8,16,108,23,32,49,99,112,19,55,89,11,107,82,47,98,22,30,60,80,66,121,10,57,17,39,79,4,64,123,33,59,106,
        74,5,119,26,10,105,48,38,84,76,57,23,125,115,3,106,33,77,99,71,113,22,1,44,87,8,31,111,96,2,42,70,81,
        13,93,122,37,114,88,63,107,50,40,82,116,68,6,127,16,51,73,61,83,46,0,126,104,78,67,41,119,28,11,56,47,4,
        21,52,66,15,98,24,7,30,91,112,35,55,124,64,5,95,32,49,9,85,65,43,18,92,36,12,86,118,60,25,72,53,80,123,
        45,58,102,110,120,89,34,17,75,94,27,100,62,20,39,108,90,69,117,97,59,79,109,101,19,121,54,29,14,74,103,
        0,93,104,36,87,125,23,97,44,107,11,3,70,35,60,77,29,84,6,91,126,15,76,56,4,89,115,99,43,22,122,16,105,55,
        2,113,78,51,63,14,120,102,8,19,68,111,86,47,64,32,121,72,59,108,96,80,25,67,118,12,58,127,20,90,9,37,103,
        53,62,69,85,10,110,34,100,119,39,73,1,83,48,112,30,54,65,45,5,123,101,26,88,18,46,95,40,109,7,27,57,66,
        116,38,75,92,21,52,61,28,106,114,94,33,17,79,42,71,124,50,82,13,31,41,117,74,98,81,24,49};

    if (length == 166)
    {
        if (stage == 0) return addr_in;
        else return int0[addr_in - 166];
    }
    else if (length == 128)
    {
        if (stage == 0) return addr_in;
        else return int1[addr_in - 128];
    }
    return 0;
}
