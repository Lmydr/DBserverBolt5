#ifndef CRC
#define CRC

#define CRC_TABLE

typedef  unsigned int uint32_t;
typedef  unsigned char uint8_t;


uint32_t digital_crc32(const uint8_t *buf, uint8_t len);


#endif // CRC

