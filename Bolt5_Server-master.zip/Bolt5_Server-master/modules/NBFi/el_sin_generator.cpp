#include "el_sin_generator.h"

#define M_PI 3.14159265358979323846

EllipticSinGenerator::EllipticSinGenerator(float in_k):
    m_z1(1.0),
    m_z2(0.0),
    m_k1(cosf(2.0 * M_PI * in_k)),
    m_k2(2.0 * sinf(M_PI * in_k)),
    m_sin(sinf(0)),
    m_cos(cosf(0)),
    m_corr_coef(1.0) {
    m_n_corr = 1000;
    float sum = 0.0;
    for(unsigned short i = 0; i < m_n_corr; i++) {
        generate();
        sum += getSin() * getSin();
    }
    m_corr_coef = -sqrt(((float)m_n_corr) / (2 * sum));
}

const EllipticSinGenerator& EllipticSinGenerator::operator=(const EllipticSinGenerator& inGen) {
    m_z1 = inGen.m_z1;
    m_z2 = inGen.m_z2;
    m_k1 = inGen.m_k1;
    m_k2 = inGen.m_k2;
    m_sin = inGen.m_sin;
    m_cos = inGen.m_cos;
    m_corr_coef = inGen.m_corr_coef;

    return *this;
}

void EllipticSinGenerator::generate() {
    float a, b, c, d, e;

    a = m_z1;
    d = m_k1 * a;
    e = d + m_z2;
    c = m_k1 * e;
    b = c - a;
    m_cos = a;
    m_sin = m_z2 * m_corr_coef;
    m_z1 = e;
    m_z2 = b;
}
