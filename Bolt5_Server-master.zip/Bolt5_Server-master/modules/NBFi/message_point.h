#ifndef MESSAGE_POINT_H
#define MESSAGE_POINT_H

#include <QTime>
#include <QDateTime>
#include <vector>

#include "preamble_point.h"

//#define MESSAGE_MAXLEN      35
#define MESSAGE_MAXLEN      39

#define DEMOD_CRC   1
#define DEMOD_1_2   2
#define DEMOD_1_3   3

#define MESSAGE_C   1
#define MESSAGE_D   2


class message_point
{
public:
    message_point();
    ~message_point();
    const message_point& operator=(const message_point& mes);
    bool operator==(message_point &a);
	bool operator<(message_point &a);
	bool operator>(message_point &a);
	QString getPayload(); 

    unsigned char TYPE;
    unsigned char packet[MESSAGE_MAXLEN];
    unsigned int ID;
    unsigned char FLAGS;
    unsigned char PAYLOAD[8];
    unsigned int P_CRC;
    unsigned char CRC8_D;
    float RSSI;
    float MAX_RSSI;
    float MIN_RSSI;
    float SNR;
    float MAX_SNR;
    float MIN_SNR;
    float NOISE;
    float IQDIV;
    quint64 FREQ;
    unsigned int batch_time;
    QDateTime time;
    unsigned int demod_method;
    unsigned int bitrate;
    preamble_point* preamble;
    preamble_point* preamble_1_3;
    unsigned char err_num;
    unsigned int rotation;
    bool calculated;
    unsigned int batch_id;
    unsigned int num_of_copies;
    unsigned int num_of_copies_1_2;
    unsigned int tmp_for_aver_freq;
    bool processed;
    bool emited;
    uint total;

    float rawData[512];
};

#endif // MESSAGE_POINT_H
