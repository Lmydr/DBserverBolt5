#include "preamble_point.h"

preamble_point::preamble_point(long x, long y, int table, long long corr, int pre, int err)
{
    x_coord = x;
    y_coord = y;
    table_no = table;
    corr_sign = corr;
    pre_sign = pre;
   // RSSI = 0;
	err_num = err;
}

