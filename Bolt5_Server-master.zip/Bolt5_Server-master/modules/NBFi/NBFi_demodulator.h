#ifndef DEMODULATOR_H
#define DEMODULATOR_H
#include <QCoreApplication>
#include <QThread>
#include <QList>
#include <QQueue>
//#include <vector>

#include <vector>

#include "defines.h"

#include "biquad.h"
#include "fft_chart.h"
#include "preamble_point.h"
#include "message_point.h"
#include "crc.h"
#include "zigzag.h"
#include "el_sin_generator.h"
#include "logger.h"
#include "GNU_UDP_client.hpp"
//#include "recorder.h"
#include "udp_clients.h"

//#include "spectrum_server.h"

#define FRAMELEN    131072
#define FRAMELEN10M 1310720

#ifdef FFTW
#include <fftw3.h>
//#include <C:\SysGCC\Raspberry\arm-linux-gnueabihf\sysroot\usr\local\include\fftw3.h>
#endif

#ifdef GPUFFT
#include	"mailbox.h"
#include	"gpu_fft.h"
#endif

#ifndef FFTW
typedef float fftwf_complex[2];
#endif

//#define SAMPLE_FREQ 51200//5000000
#define SAMPLE_FREQ 125000

#define MAX_RAW_SIZE 51200//5000000

#define BAND_DIVIDER	1

#define FFT_DRAW_CYCLE  10  //5 times per second
#define NOISE_AVER_NUM 50 //10



//#define FFT_SIZE    fft_size //(SAMPLE_FREQ/BAND_DIVIDER/sym_rate)
#define FFT_SIZE    (SAMPLE_FREQ/BAND_DIVIDER/DEFAULT_SYM_RATE)

#define CENTER_FREQ uplink_freq //868800000

#define TABLE_MAX_NUM   50

#define DEFAULT_SYM_RATE    50
#define DEFAULT_TABLE_NUM   4
#define DEFAULT_ROTATES_NUM   2
#define DEFAULT_MAX_PRE_ERRORS  1 //4
#define DEFAULT_MAX_PRE_CALC  300 //4
#define DEFAULT_MAX_PRE_CALC_1_3 5	

#define DELTA 4

#define DEFAULT_DECODE_1_2

#define DEFAULT_PROT_C
#define DEFAULT_PROT_D


//#define PREAMBLE_64_BIT

#ifdef PREAMBLE_64_BIT
    //#define PREAMBLE_C      0x911A4C8f11111111
    #define PREAMBLE_C      0x9220b5a6b642fd1f
    #define MESSAGE_C_MAXLEN_W_O_ZIGZAG    23   //bytes
    #define MESSAGE_D_MAXLEN_W_O_ZIGZAG    24
    #define num_of_bits(x) num_of_bits64(x)
#else
    #define PREAMBLE_C    ((0x97<<24)+(0x15<<16)+(0x7A<<8)+0x6F) //old
    //#define PREAMBLE_C    ((0x6F<<24)+(0x7A<<16)+(0x15<<8)+0x97) //old inv
    //#define PREAMBLE_C    ((0x91<<24)+(0x1A<<16)+(0x4C<<8)+0x8F) //new
    #define MESSAGE_C_MAXLEN_W_O_ZIGZAG    19   //bytes
    #define MESSAGE_D_MAXLEN_W_O_ZIGZAG    20
    #define num_of_bits(x) num_of_bits32(x)
#endif

#define INVPREAMBLE_C    (~PREAMBLE_C)


#define MESSAGE_C_MAXLEN    152 //bits
#define AT_LEAST_FOR_DECODE 280

/*
#define PREAMBLE_B    ((0xAA<<16)+(0xF0<<8)+0x99)
#define PREAMBLE_S    ((0xCC<<16)+(0xBB<<8)+0xDD)
#define PREAMBLE_E    ((0x55<<16)+(0x55<<8)+0x99)

#define INVPREAMBLE_B    ((~PREAMBLE_B)&0xffffff)
#define INVPREAMBLE_S    ((~PREAMBLE_S)&0xffffff)
#define INVPREAMBLE_E    ((~PREAMBLE_E)&0xffffff)
*/


class NBFiDemodulator : public QThread
{
Q_OBJECT
public:
 explicit  NBFiDemodulator();
~NBFiDemodulator();
    //void setLogpath(QString lp){logpath = lp;}
    void set_log_offset(float logoffset) {LogOffset = logoffset;}
    void setULFreq(quint32 freq) {uplink_freq = freq;}
    bool rawdataprocessed();
    bool inProgress();
    bool getNextChart(fft_chart *chart);
    void find_preambles();
    unsigned int find_preambles_near(unsigned int x_c, unsigned int y_c);
    void decode_messages();
    void filter_messages(QList<message_point*> &in_list, QList<message_point*> &out_list);
    void calc_messages(QList<message_point*> &m_p);
    float getAverNoise();
    void rotateI_Q(uint);
    static void initFreq();
    float getBatchLen();
    void clear_all();
    void setSymRate(uint sr = DEFAULT_SYM_RATE);
    uint symRate() {return sym_rate;}
    void setTablesNum(uint num = DEFAULT_TABLE_NUM) {tables_num = num; }
	void setRotatesNum(uint num = DEFAULT_ROTATES_NUM) {rotates_num = num; }
	void setMaxPreErrors(uint max_err = DEFAULT_MAX_PRE_ERRORS) {max_pre_errors = max_err; }
	void setMaxPreCalc(uint max_calc = DEFAULT_MAX_PRE_CALC) {max_pre_calc = max_calc; }
	void setMaxPreCalc_1_3(uint max_calc = DEFAULT_MAX_PRE_CALC_1_3) {max_pre_calc_1_3 = max_calc; }
	void setDecode_1_2(bool decode = true) {decode_1_2 = decode;}
	void setDecode_1_3(bool decode = true) {decode_1_3 = decode; }
    void setDecode_C(bool decode = true) {decode_prot_c = decode; }
    void setDecode_D(bool decode = true) {decode_prot_d = decode; }
    //void setMutex(QMutex *m) {m_mutex = m;}
    void setRecordToFile(bool en = true) {record_to_file = en;}
    void setI_Q_reverse(bool en = true) {i_q_reverse = en;}
    void run();
    void setI_QData(qint16 *i_q, unsigned int data_len);
    void setI_QData(float *i_q, unsigned int data_len);
    void work(qint16 *i_q, unsigned int data_len);
    void work(float *i_q, unsigned int data_len);
protected:

    //void convert_to_low_freq();
    void build_fft_tables();
    unsigned int  num_of_bits32(unsigned int _arg);
    unsigned int  num_of_bits64(unsigned long long _arg);
    void save_to_file();

    void setI_QData(fftwf_complex *i_q, unsigned int data_len);

    std::vector<float> vec;
signals:
    //void fft_chart_ready(float* fft_ampl, long len);
    void messages_ready(NBFiDemodulator* dem);
    //void lock();
    //void unlock();


public:

    QList<message_point*> filtered_list;
    char IQdata[FRAMELEN*16];

    static uint batch_id_counter;

    uint batch_id;
    QDateTime start_time;
    QDateTime run_start;

    uint dem_id;
    float LogOffset = 216;

    int msgcount = 0;
private:
    uint  sym_rate;
    uint  fft_size;
    uint  tables_num = 3;
    uint  rotates_num = 3;
    uint  max_pre_errors = 5;
    uint  max_pre_calc = 100;
    uint  max_pre_calc_1_3 = 3;
    bool  decode_1_2 = true;
    bool  decode_1_3 = false;
    bool  decode_prot_c = true;
    bool  decode_prot_d = true;

    qint16* raw_data;
    long raw_data_len;
    long symb_over_len;

    long dataSize;

    fftwf_complex    *zeroF_I_Q;
    fftwf_complex    *zeroF_I_Q_rot;

#ifdef FFTW
    fftwf_complex *fft_in, *fft_out;
    fftwf_plan fft_plan;
#endif

#ifdef GPUFFT
	int mb;
	struct GPU_FFT_COMPLEX *base;
	struct GPU_FFT *gfft;
#endif

    //QMutex* m_mutex;
    fftwf_complex * fft_table[TABLE_MAX_NUM];
    fftwf_complex * corr_table[TABLE_MAX_NUM];


    float noise_lev[TABLE_MAX_NUM][2500];

    float noise_lev_min[TABLE_MAX_NUM][2500];

    bool inprogr;
    bool processing;
	bool should_end;

    QQueue<fft_chart*>   charts;

    QList<preamble_point*> p_list;
	QList<preamble_point*> near_p_list;

	uint pre_found_num_for_each_error[33];

    QList<message_point*> m_list;


    bool zero_to_delete;

    uint Rotation;
	QDateTime processing_timer;
    quint32 uplink_freq;
    bool record_to_file;
    bool i_q_reverse;

    std::vector<float> window;
};

#endif // DEMODULATOR_H
