#ifndef FFT_CHART_H
#define FFT_CHART_H

#include <QTime>

class fft_chart
{
public:
    fft_chart(long len = 1024);

    ~fft_chart();

    float* getdata();
    void setdata(float *indata);
    long size();
    void resize(long);
    long getlen();
    void setTime(const QTime &t);
    QTime time();
private:
    float *data;
    long    data_len;
    QTime ch_time;
};

#endif // FFT_CHART_H
