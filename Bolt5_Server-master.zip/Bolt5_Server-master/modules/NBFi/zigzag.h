#ifndef ZIGZAG
#define ZIGZAG

void zigzag_decoder_soft_var_len(float* d_in, int* d_out/*, float* d_out_soft*/);
void zigzag_decoder_iter_soft_var_len(float* data, float* parity,short stage, float* delta);
float min_abs_prod_soft_var_len(float a1, float a2,float a3);
int get_data_addr_soft_var_len(int addr_in, short stage);

#endif // ZIGZAG

