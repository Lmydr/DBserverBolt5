#ifndef FIFOFER_H
#define FIFOFER_H

#include <sys/wait.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <string.h>
#include <string>
#include <fcntl.h>

class FIFOfer
{
public:
    FIFOfer();

    static void init(int port);
    static void writeTo();
    static int readFrom();

    static char buff[1024];
private:
    static int dfifo;
};

#endif // FIFOFER_H
