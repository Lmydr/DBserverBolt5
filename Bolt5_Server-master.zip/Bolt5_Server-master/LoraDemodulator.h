/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   mainDecoder.h
 * Author: DEF
 *
 * Created on 29 мая 2019 г., 15:16
 */

#ifndef MAINDECODER_H
#define MAINDECODER_H

#include <QThread>
#include <vector>
#include <string>

#include "DBuffer.h"
#include "modules/LoraWAN/decoder_impl.h"
//#include "mainheader.h"
#include "ttngatewayconnector.h"

class mainDecoder : public QThread
{
    Q_OBJECT
public:
    DBuffer buff;
    TTNGatewayConnector* ttn;
    gr::lora::decoder_impl* loradec;

    mainDecoder();
    void loraTestInit();
    void loraInit(std::string name, std::string key);
    void run();
    void msgDecoded_cb(char* data, int size);

    virtual ~mainDecoder();
private:

};

#endif /* MAINDECODER_H */

