#include "defines.h"

#include <complex>
#include <QTimer>
#include <QThread>
#include <QDebug>
#include <QFile>

//#include <asoundlib.h>
//#include "client.h"



//#define FRAMELEN 147456 //subbatch len =  2.88 sec, 144 sym on 50bps
#define FRAMELEN 131072
//#define FRAMELEN 18432 //subbatch len =  0.36 sec, 144 sym on 400bps
//#define FRAMELEN 16384
#define BATCH_LEN_50BPS     (6*8)
#define BATCH_OFFSET_50BPS  (4*8)
#define BATCH_LEN_400BPS     (8)
#define BATCH_OFFSET_400BPS  (6)


class Batch
{   
public:
    Batch(uint blen, uint offlen, uint per )
    {
        batchlen = blen;
        pointer = 0;
        subbatch = -((signed)offlen);
        period = per;
        zeroF_I_Q = new qint16[2*FRAMELEN*(batchlen + 1)];
        I_Q = new std::complex<float>[FRAMELEN*(batchlen + 1)];
    }
    ~Batch()
    {
        delete zeroF_I_Q;
    }

public:
    qint16      *zeroF_I_Q;
    std::complex<float> *I_Q;
    signed int  subbatch;
    uint        batchlen;
    uint        period;
    //uint        offsetlen;
    uint        pointer;

};


class Recorder : public QObject
{
    Q_OBJECT
public:
   explicit Recorder(QObject *parent = 0);
    ~Recorder();
   void addBatch(Batch * b, uint thread);
   void getFromTCP(qint16* alsa_capture_buffer, unsigned int capture_size);
private:

    //int StartPCM();
    //void StopPCM();

protected:
//	void run();


signals:
    void I_Q_isready1(qint16 *I_Q, unsigned int len);
private:

    QTimer *timer;

    //snd_pcm_t *capture_handle;
    //snd_pcm_hw_params_t *hw_params;

    Batch *batches[8];
    //Client client;

  /*  qint16    *zeroF_I_Q[THREADS];
    signed int subbatch[THREADS];
    uint    batchlen[THREADS];
    uint    overlen[THREADS];
    uint     pointer[THREADS];*/

    //qint16    *zeroF_I_Q[THREADS];




};

