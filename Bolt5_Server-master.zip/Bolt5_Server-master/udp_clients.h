#ifndef UDP_CLIENTS_H
#define UDP_CLIENTS_H

#include <string>
#include "GNU_UDP_client.hpp"

class UDP_Clients
{
public:
    static void init();

    static udp_client* udp1233;
    static udp_client* udp1234;
    static udp_client* udp1235;
};

#endif // UDP_CLIENTS_H
