#include "logger.h"


long long DEFiusLogger::startTime;
std::fstream* DEFiusLogger::static_file;

DEFiusLogger::DEFiusLogger(std::string _filename) {
    filename = _filename;

    file.open(filename, std::ios_base::app);

    long long time = std::chrono::duration_cast<std::chrono::microseconds>(
                       std::chrono::high_resolution_clock::now().time_since_epoch()).count() - startTime;

    operator << ("[" + std::to_string(US2S(time)) + "s " + std::to_string(US2MS(time)) + "ms " + std::to_string(US2US(time)) + "us] ");
}

DEFiusLogger::DEFiusLogger() {

    long long time = std::chrono::duration_cast<std::chrono::microseconds>(
                       std::chrono::high_resolution_clock::now().time_since_epoch()).count() - startTime;

    operator << ("[" + std::to_string(US2S(time)) + "s " + std::to_string(US2MS(time)) + "ms " + std::to_string(US2US(time)) + "us] ");
}

DEFiusLogger::~DEFiusLogger() {
    if (file.is_open())
        file.close();
}

void DEFiusLogger::save() {
    static_file->flush();
}

void DEFiusLogger::out() {
    //operator << ("[" + std::to_string(US2S(time)) + "s " + std::to_string(US2MS(time)) + "ms " + std::to_string(US2US(time)) + "us] ");
}

void DEFiusLogger::close() {

    if (static_file->is_open())
        static_file->close();
}

void DEFiusLogger::setStaticLogFile(std::string filename) {
    if (static_file) {
        if (static_file->is_open())
            static_file->close();
    }
    else
        static_file = new std::fstream;

     static_file->open(filename, std::ios_base::app);

    if (!static_file->is_open()) {
        perror("DEFiusLogger::setStaticLogFile");
    }
}

void DEFiusLogger::initStartTime() {
    startTime = std::chrono::duration_cast<std::chrono::microseconds>(
                    std::chrono::high_resolution_clock::now().time_since_epoch()).count();
}






