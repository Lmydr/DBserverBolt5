#include "superbuffer.h"

#ifdef USE_LORA
SuperBuffer::SuperBuffer() {

    b10MB.reserve(1);
    b10MF.reserve(1);


    noiseArray = new gr_complex[NOISE_LEN];
    noiseArrayB = new uint8_t[NOISE_LEN];

    b250KGRC = new std::vector<gr_complex>[CHANNELS];

    for (int ch=0; ch<CHANNELS; ch++)
        b250KGRC[ch].reserve(1);


    for (int i=0; i<CHANNELS; i++)
        b125KF[i].reserve(1);

    in = (fftwf_complex*) fftwf_malloc(sizeof(fftwf_complex) * CHANNELS*2);
    out = (fftwf_complex*) fftwf_malloc(sizeof(fftwf_complex) * CHANNELS);
    p = fftwf_plan_dft_1d(CHANNELS, in, out, FFTW_FORWARD, FFTW_MEASURE);
    dp = fftwf_plan_dft_1d(CHANNELS, &in[CHANNELS/2], out, FFTW_FORWARD, FFTW_MEASURE);

    fakeIn = (uint64_t*)in;
    fakeTable = (uint64_t**)table;

    generateTable();
    //generateNoise();
}

void SuperBuffer::addNoise(double ampl) {
    for (int i=0; i<b10MF.size(); i++) {
        double temp1;
        double temp2;
        double result;
        int p;

        p = 1;

        while( p > 0 ){
            temp2 = ( rand() / ( (double)RAND_MAX ) );

            if ( temp2 == 0 ) {
                p = 1;
            }
            else {
                p = -1;
            }
        }

        temp1 = cos( ( 2.0 * (double)M_PI ) * rand() / ( (double)RAND_MAX ) );
        result = sqrt( -2.0 * log( temp2 ) ) * temp1;

        b10MF[i] += result*ampl;
    }
}

void SuperBuffer::addNoiseToFB() {
    for (int i=0; i<b10MF.size(); i+=2) {
        b10MF[i] += noise[noisePtr];
        b10MF[i+1] += noise[noisePtr+1];
        noisePtr = (noisePtr + 2) % NOISE_LEN;
    }
}

void SuperBuffer::addNoiseToFB(double ampl) {
    for (int i=0; i<b10MF.size(); i+=2) {
        b10MF[i] += noise[noisePtr] * ampl;
        b10MF[i+1] += noise[noisePtr+1] * ampl;
        noisePtr = (noisePtr + 2) % NOISE_LEN;
    }
}

void SuperBuffer::addNoise(int ch) {
    int delta = rand() % (NOISE_LEN - b250KGRC[ch].size());

    for (int i=0; i<b250KGRC[ch].size(); i++) {
        b250KGRC[ch][i] += noiseArray[i + delta];
    }
}

void SuperBuffer::addNoiseToBB(int) {
    int delta = rand() % (NOISE_LEN - b10MB.size());

    for (int i=0; i<b10MB.size(); i++) {
        b10MB[i] ^= noiseArrayB[i + delta];
    }
}

void SuperBuffer::generateNoise() {

    for (int i=0; i<NOISE_LEN*2; i++) {
        double temp1;
        double temp2;
        double result;
        int p;

        p = 1;

        while( p > 0 ){
            temp2 = ( rand() / ( (double)RAND_MAX ) );

            if ( temp2 == 0 ) {
                p = 1;
            }
            else {
                p = -1;
            }
        }

        temp1 = cos( ( 2.0 * (double)M_PI ) * rand() / ( (double)RAND_MAX ) );
        result = sqrt( -2.0 * log( temp2 ) ) * temp1;

        noise[i] = result;
    }

/*
    memcpy(noise + NOISE_LEN, noise, BLN);

    for (int i=0; i < NOISE_LEN; i++) {
        float iqC = 0.0;
        for (int j=0; j<BLN; j++) {
            iqC += noise[i + j]*BN[j];
        }
        noise[i] = iqC;
    }
*/

    memcpy(noise + NOISE_LEN, noise, BLN*2);
    for (int i=0; i < NOISE_LEN; i += 2) {
        float iC = 0.0, qC = 0.0;
        for (int j=0; j<BLN; j++) {
            iC += noise[i + j*2]*BN[j];
            qC += noise[i + j*2 + 1]*BN[j];
        }
        noise[i]   = iC;
        noise[i+1] = qC;
    }
    //for (int i=0; i< 100; i++)
    //qDebug() << noise[i*2] << noise[i*2+1];

}

void SuperBuffer::generateTable() {
    for (int ch=0; ch < CHANNELS; ch++) {
        for (int j=0; j<=0xFF; j++) {
            float iC = 0;
            float qC = 0;

            for (int b=3; b>=0; b--) {
                qC += (j>>(b*2    )&1 ? -1.0f : 1.0f) * B[ch + b*CHANNELS];
                iC += (j>>(b*2 + 1)&1 ? -1.0f : 1.0f) * B[ch + b*CHANNELS];
            }

            table[ch][j][0] = iC;
            table[ch][j][1] = qC;
        }
    }


    for (int i=0; i<BL; i++) {
        B2[i*2  ] = B[i];
        B2[i*2+1] = B[i];
    }
}

void SuperBuffer::getSubChannels125KFromFB() {
    gr_complex* dataIn = getFB_grc();

    int i;
    // CHANNELS = 80
    for (i=0; i <b10MF.size()/2 - BL; i+=CHANNELS) {
        for (int ch=0; ch<CHANNELS; ch++) {
            float iC = 0.0;
            float qC = 0.0;

            for (int j=0; j<BL/CHANNELS; j++) {
                iC += dataIn[i + ch + j*CHANNELS].real() * B[ch + j*CHANNELS];
                qC += dataIn[i + ch + j*CHANNELS].imag() * B[ch + j*CHANNELS];
            }

            in[ch][0] = iC;
            in[ch][1] = qC;
        }

        fftwf_execute(p);

        for (int ch=0; ch<CHANNELS; ch++) {
            b125KF[ch].push_back(out[ch][0]);
            b125KF[ch].push_back(out[ch][1]);
        }
    }

    i -= CHANNELS;
    b10MF.erase(b10MF.begin(), b10MF.begin() + i*2);
}


void SuperBuffer::getSubChannels125KFromBB() {
    int i;

    for (i=0; i <b10MB.size() - BL/4; i+= CHANNELS/4) {
        for (int ch=0; ch<CHANNELS; ch++) {
            uint8_t frameArray = 0;

            for (int fr=0; fr<4; fr++) {
                frameArray = (frameArray << 2) | (b10MB[i + ch/4] >> ((3 - ch%4)*2)) & 0b11;
            }
            in[ch][0] = table[ch][frameArray][0];
            in[ch][1] = table[ch][frameArray][1];
        }

        fftwf_execute(p);

        for (int ch=0; ch<CHANNELS; ch++) {
            b125KF[ch].push_back(out[ch][0]);
            b125KF[ch].push_back(out[ch][1]);
        }
    }

    i -= CHANNELS;
    b10MB.erase(b10MB.begin(), b10MB.begin() + i);
}

bool b250 = false;

#define TEST250K 0

void SuperBuffer::getSubChannels250KFromFB() {
    gr_complex* dataIn = getFB_grc();
    fftwf_complex mulBuff[BL];

    int i;

    for (i=0; i < size10MF_grc() - BL; i += CHANNELS/2) { // CHANNELS = 80
#if TEST250K == 1
        float* inPtr = (float*)&dataIn[i];
        volk_32f_x2_multiply_32f(inPtr, B2, (float*)mulBuff, BL*2);

        for (int ch=0; ch<CHANNELS; ch++) {
            in[ch][0] = 0.0;
            in[ch][1] = 0.0;

            for (int j=0; j < BL/CHANNELS; j++) {
                if (b250) {
                    in[ch][0] += mulBuff[ch + j*CHANNELS][0];
                    in[ch][1] += mulBuff[ch + j*CHANNELS][1];
                }
                else {
                    if (ch < CHANNELS/2) {
                        in[ch + CHANNELS/2][0] += mulBuff[ch + j*CHANNELS][0];
                        in[ch + CHANNELS/2][1] += mulBuff[ch + j*CHANNELS][1];
                    }
                    else {
                        in[ch - CHANNELS/2][0] += mulBuff[ch + j*CHANNELS][0];
                        in[ch - CHANNELS/2][1] += mulBuff[ch + j*CHANNELS][1];
                    }
                }
            }

        }
#else
        for (int ch=0; ch<CHANNELS; ch++) {
            fftwf_complex tmp = {0.0, 0.0};
            uint64_t* fakeInt = (uint64_t*)&tmp;

            for (int j=0; j < BL/CHANNELS; j++) {
                tmp[0] += dataIn[i + ch + j*CHANNELS].real() * B[j*CHANNELS+ch];
                tmp[1] += dataIn[i + ch + j*CHANNELS].imag() * B[j*CHANNELS+ch];
            }

            if (b250) {
                ((int64_t*)in)[ch] = *fakeInt;
            }
            else {
                if (ch < CHANNELS/2) {
                    ((int64_t*)in)[ch + CHANNELS/2] = *fakeInt;
                }
                else {
                    ((int64_t*)in)[ch - CHANNELS/2] = *fakeInt;
                }
            }
        }
#endif
        fftwf_execute(p);

        for (int ch=0; ch<CHANNELS; ch++) {
            //b250KF[ch].push_back(out[ch][0]);
            //b250KF[ch].push_back(out[ch][1]);
            gr_complex ins(out[ch][0],out[ch][1]);
            b250KGRC[ch].push_back(ins);
        }

        b250 = !b250; // Смена чётности на нечётность и наоборот
    }
    i -= CHANNELS/2;
    b10MF.erase(b10MF.begin(), b10MF.begin() + i*2);
}

bool b250b = false;

void SuperBuffer::getSubChannels250KFromBB() {
    int i;

    for (i=0; i < size10MB_grc() - BL; i += CHANNELS/2) {
        for (int ch=0; ch<CHANNELS; ch++) {
            uint8_t frameArray;// = rand();

            for (int j=0; j < BL/CHANNELS; j++) { // 14 %
                frameArray = (frameArray << 2) | getFrameFromBB(i + ch + j*CHANNELS);
            }

            if (b250b) { //14 %
                //in[ch] = table[ch][frameArray];
                //*(uint64_t*)in[ch] = *(uint64_t*)table[ch][frameArray];
                fakeIn[ch] = *(uint64_t*)table[ch][frameArray];//fakeTable[ch][frameArray];
                //in[ch][0] = table[ch][frameArray][0];
                //in[ch][1] = table[ch][frameArray][1];
            }
            else {
                if (ch < CHANNELS/2) {
                    //*(uint64_t*)in[ch + CHANNELS/2] = *(uint64_t*)table[ch][frameArray];
                    fakeIn[ch + CHANNELS/2] = *(uint64_t*)table[ch][frameArray];// fakeTable[ch][frameArray];
                    //in[ch + CHANNELS/2][0] = table[ch][frameArray][0];
                    //in[ch + CHANNELS/2][1] = table[ch][frameArray][1];
                }
                else {
                    //*(uint64_t*)in[ch - CHANNELS/2] = *(uint64_t*)table[ch][frameArray];
                    fakeIn[ch - CHANNELS/2] = *(uint64_t*)table[ch][frameArray];//fakeTable[ch][frameArray];
                    //in[ch - CHANNELS/2][0] = table[ch][frameArray][0];
                    //in[ch - CHANNELS/2][1] = table[ch][frameArray][1];
                }
            }
        }


        fftwf_execute(p); // 5 %
        //qDebug() << b250KGRC[0].size();
#ifdef IGNORE_18_CHANNELS
        for (int ch=0; ch<CHANNELS-18; ch++) {
#else
        for (int ch=0; ch<CHANNELS; ch++) {
#endif
            b250KGRC[ch].push_back(gr_complex(out[ch][0],out[ch][1]));
        }

        b250b = !b250b;
    }
    if (i != 0)
        i -= CHANNELS/2;
    b10MB.erase(b10MB.begin(), b10MB.begin() + i/4);
}

uint8_t inline SuperBuffer::getFrameFromBB(int fr) {
    return (b10MB[fr/4] >> ((3 - fr%4)*2)) & 0b11;
}

void SuperBuffer::BBToFB() {
    for (int i=0; i<b10MB.size(); i++) {
        for (int b=7; b >= 0; b--) {
            if ((b10MB[i] >> b) & 1)
                b10MF.push_back(-1.0);
            else {
                b10MF.push_back( 1.0);
            }
        }
    }
}

void SuperBuffer::BBToFB(int size) {
    for (int i=0; i<size/4; i++) {
        for (int b=7; b >= 0; b--) {
            if ((b10MB[i] >> b) & 1)
                b10MF.push_back(-1.0);
            else {
                b10MF.push_back( 1.0);
            }
        }
    }
}

void SuperBuffer::FBToBB() {
    uint32_t* ptr = (uint32_t*)b10MF.data();

    for(int i=0; i < b10MF.size()/8; i++) {
        uint8_t ins = 0;
        for (int b=0; b<8; b++) {
            ins = (ins<<1) | ((ptr[i*8 + b] >> 31)&1);
        }

        b10MB.push_back(ins);
        //b10MB.erase(b10MB.begin(), b10MB.begin() + 80*4*2);
    }
}

void SuperBuffer::insertToBB(float* in, unsigned long long  size) {
    uint32_t* ptr = (uint32_t*)in;

    for (int i=0; i < size; i+=8) {
        uint8_t ins = 0;
        for (int b=0; b<8; b++) {
            ins = (ins << 1) | ((ptr[i + b] >> 31)&1);
        }
        b10MB.push_back(ins);
    }
}

void SuperBuffer::insertToBB(uint8_t* in, unsigned long long  size) {
    b10MB.insert(b10MB.end(), in, in + size);
}

void SuperBuffer::insertToBB(gr_complex* in, unsigned long long  size) {
    insertToBB((float*)in, size*2);
}

void SuperBuffer::insertToBB(fftwf_complex* in, unsigned long long  size) {
    insertToBB((float*)in, size*2);
}

void SuperBuffer::insertToFB(float* in, unsigned long long  size) {
    b10MF.insert(b10MF.end(), in, in + size);
}

void SuperBuffer::insertToFB(uint8_t* in, unsigned long long  size) {
    for (int i=0; i<size; i++) {
        for (int b=7; b >= 0; b--) {
            if ((in[i] >> (b)) & 1)
                b10MF.push_back(-1.0);
            else {
                b10MF.push_back(1.0);
            }
        }
    }
}

void SuperBuffer::insertToFB(gr_complex* in, unsigned long long  size) {
    b10MF.insert(b10MF.end(), (float*)in, (float*)in + size*2);
}

void SuperBuffer::insertToFB(fftwf_complex* in, unsigned long long  size) {
    b10MF.insert(b10MF.end(), (float*)in, (float*)in + size*2);
}

fftwf_complex* SuperBuffer::getFB_fftwfc() {
    return (fftwf_complex*)b10MF.data();
}

gr_complex* SuperBuffer::getFB_grc() {
    return (gr_complex*)b10MF.data();
}

float* SuperBuffer::getFB_f() {
    return b10MF.data();
}

fftwf_complex* SuperBuffer::get125KB_fftwfc(int ch) {
    return (fftwf_complex*)(b125KF[ch].data());
}

gr_complex* SuperBuffer::get125KB_grc(int ch) {
    return (gr_complex*)(b125KF[ch].data());
}

float* SuperBuffer::get125KB_f(int ch) {
    return b125KF[ch].data();
}

fftwf_complex* SuperBuffer::get250KB_fftwfc(int ch) {
    return (fftwf_complex*)(b250KGRC[ch].data());
}

gr_complex* SuperBuffer::get250KB_grc(int ch) {
    return (gr_complex*)(b250KGRC[ch].data());
}

float* SuperBuffer::get250KB_f(int ch) {
    return (float*)b250KGRC[ch].data();
}


int SuperBuffer::size125K_f() {
    return b125KF[0].size();
}

int SuperBuffer::size125K_grc() {
    return b125KF[0].size()/2;
}

int SuperBuffer::size125K_fftw() {
    return b125KF[0].size()/2;
}

int SuperBuffer::size250K_f() {
    return b250KGRC[0].size()*2;
}

int SuperBuffer::size250K_grc() {
    return b250KGRC[0].size();
}

int SuperBuffer::size250K_fftw() {
    return b250KGRC[0].size();
}

int SuperBuffer::size10MB_f() {
    return b10MB.size()*8;
}

int SuperBuffer::size10MB_grc() {
    return b10MB.size()*4;
}

int SuperBuffer::size10MB_fftw() {
    return b10MB.size()*4;
}

int SuperBuffer::size10MF_f() {
    return b10MF.size();
}

int SuperBuffer::size10MF_grc() {
    return b10MF.size()/2;
}

int SuperBuffer::size10MF_fftw() {
    return b10MF.size()/2;
}

void SuperBuffer::erase_f(int size) {
    for (int ch=0; ch<CHANNELS; ch++)
        b125KF[ch].erase(b125KF[ch].begin(), b125KF[ch].begin() + size);
}

void SuperBuffer::erase_grc(int size) {
    erase_f(size*2);
}

void SuperBuffer::erase_fftwf(int size) {
    erase_f(size*2);
}

void SuperBuffer::cleanBB() {
    b10MB.clear();
}

void SuperBuffer::cleanFB() {
    b10MF.clear();
}

void SuperBuffer::clean125KB() {
    for (int ch=0; ch<80; ch++) {
        b125KF[ch].clear();
    }
}

void SuperBuffer::clean250KB() {
    for (int ch=0; ch<80; ch++) {
        b250KGRC[ch].clear();
    }
}

std::vector<gr_complex>* SuperBuffer::getVec250KGRC(int ch) {
    return  &(b250KGRC[ch]);
}

SuperBuffer::~SuperBuffer() {
    fftwf_free(in);
    fftwf_free(out);
    fftwf_destroy_plan(p);
    fftwf_destroy_plan(dp);

    delete [] noiseArray;
    delete [] noiseArrayB;

    delete [] b250KGRC;

}

#endif
