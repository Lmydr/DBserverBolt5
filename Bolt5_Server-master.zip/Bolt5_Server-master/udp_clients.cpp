#include "udp_clients.h"

udp_client* UDP_Clients::udp1233;
udp_client* UDP_Clients::udp1234;
udp_client* UDP_Clients::udp1235;

void UDP_Clients::init() {
    //std::string IP = "188.134.87.224";
    std::string IP = "localhost";

    UDP_Clients::udp1233 = new udp_client(IP, 1233);
    UDP_Clients::udp1234 = new udp_client(IP, 1234);
    UDP_Clients::udp1235 = new udp_client(IP, 1235);
}
