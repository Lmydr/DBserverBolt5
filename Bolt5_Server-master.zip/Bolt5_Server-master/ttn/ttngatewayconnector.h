#ifndef TTNGATEWAYCONNECTOR_H
#define TTNGATEWAYCONNECTOR_H

#include "string"
#include <connector.h>

class TTNGatewayConnector
{
public:
    TTNGatewayConnector(std::string gw_id, std::string gw_key);
    ~TTNGatewayConnector();
    void send(char* data, int size);
    static void print_downlink(Router__DownlinkMessage *msg, void *arg);
private:
    TTN *ttn;
    int count = 0;
};

#endif // TTNGATEWAYCONNECTOR_H
