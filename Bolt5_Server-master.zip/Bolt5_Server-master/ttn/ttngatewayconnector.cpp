#include "ttngatewayconnector.h"

TTNGatewayConnector::TTNGatewayConnector(std::string gw_id, std::string gw_key) {
    ttngwc_init(&ttn, gw_id.data(), &TTNGatewayConnector::print_downlink, NULL);
    if (!ttn) {
        printf("TTN: failed to initialize TTN gateway\n");
        return;
    }

    printf("TTN: connecting...\n");
    int err = ttngwc_connect(ttn, "router.eu.thethings.network", 1883, gw_key.data());
    if (err != 0) {
        printf("TTN: connect failed: %d\n", err);
        ttngwc_cleanup(ttn);
        return;
    }
    printf("TTN: connected\n");
}

void TTNGatewayConnector::send(char* data, int size) {
    Gateway__Status status = GATEWAY__STATUS__INIT;
        status.has_time = 1;
        int err = ttngwc_send_status(ttn, &status);
        if (err)
          printf("status: send failed: %d\n", err);
        else
          printf("status: sent\n");

        // Enter the payload
        Router__UplinkMessage up = ROUTER__UPLINK_MESSAGE__INIT;
        up.has_payload = 1;
        up.payload.len = size;
        up.payload.data = (uint8_t*)data;

        // Set protocol metadata
        Protocol__RxMetadata protocol = PROTOCOL__RX_METADATA__INIT;
        protocol.protocol_case = PROTOCOL__RX_METADATA__PROTOCOL_LORAWAN;
        Lorawan__Metadata lorawan = LORAWAN__METADATA__INIT;
        lorawan.has_modulation = 1;
        lorawan.modulation = LORAWAN__MODULATION__LORA;
        lorawan.data_rate = "SF7BW125";
        lorawan.coding_rate = "4/5";
        lorawan.has_f_cnt = 1;
        lorawan.f_cnt = count++;
        protocol.lorawan = &lorawan;
        up.protocol_metadata = &protocol;

        // Set gateway metadata
        Gateway__RxMetadata gateway = GATEWAY__RX_METADATA__INIT;
        gateway.has_timestamp = 1;
        //gateway.timestamp = 10000 + i * 100;
        gateway.has_rf_chain = 1;
        gateway.rf_chain = 5;
        gateway.has_frequency = 1;
        gateway.frequency = 867100000;
        up.gateway_metadata = &gateway;

        // Send uplink message
        err = ttngwc_send_uplink(ttn, &up);
        if (err)
          printf("up: send failed: %d\n", err);
        else
          printf("up: sent\n");
}

TTNGatewayConnector::~TTNGatewayConnector() {
    ttngwc_disconnect(&ttn);
    ttngwc_cleanup(&ttn);
}

void TTNGatewayConnector::print_downlink(Router__DownlinkMessage *msg, void *arg) {
    if (msg->has_payload) {
        printf("TTN: down: have %zu bytes downlink\n", msg->payload.len);
        switch (msg->protocol_configuration->protocol_case) {
            case PROTOCOL__TX_CONFIGURATION__PROTOCOL_LORAWAN: {
                Lorawan__TxConfiguration *lora = msg->protocol_configuration->lorawan;
                printf( "TTN: down: modulation: %d, data rate: %s, bit rate: %d, coding rate: "
                        "%s, fcnt: %d\n",
                        lora->modulation, lora->data_rate, lora->bit_rate,
                        lora->coding_rate, lora->f_cnt);

                Gateway__TxConfiguration *gtw = msg->gateway_configuration;
                printf( "TTN: down: timestamp: %d, rf chain: %d, frequency: %llu, power: %d, "
                        "polarization inversion: %d, frequency deviation: %d\n",
                        gtw->timestamp, gtw->rf_chain, gtw->frequency, gtw->power,
                        gtw->polarization_inversion, gtw->frequency_deviation);

                break;
            }
            default:
                printf("TTN: down: invalid protocol %d\n", msg->protocol_configuration->protocol_case);
                break;
        }
    }
}
