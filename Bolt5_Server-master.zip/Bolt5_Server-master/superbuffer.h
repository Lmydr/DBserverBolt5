#ifndef SUPERBUFFER_H
#define SUPERBUFFER_H

#ifdef USE_LORA

#include <QTime>
#include <QDebug>
#include <vector>
#include <fftw3.h>
#include <volk/volk.h>


#include "modules/LoraWAN/LoraDemodulator.h"
#include "fdacoefs.h"
#include "noise.h"

#define CHANNELS 80
#define NOISE_LEN (1024*1024*25+94)
#define IGNORE_18_CHANNELS

class SuperBuffer
{
public:
    SuperBuffer();
    ~SuperBuffer();
    void getSubChannels125KFromBB();
    void getSubChannels125KFromFB();

    void getSubChannels250KFromBB();
    void getSubChannels250KFromFB();

    void BBToFB();
    void BBToFB(int);
    void FBToBB();

    void insertToBB(float*, unsigned long long );
    void insertToBB(uint8_t*, unsigned long long );
    void insertToBB(gr_complex*, unsigned long long );
    void insertToBB(fftwf_complex*, unsigned long long );

    void insertToFB(float*, unsigned long long );
    void insertToFB(uint8_t*, unsigned long long );
    void insertToFB(gr_complex*, unsigned long long );
    void insertToFB(fftwf_complex*, unsigned long long );

    float* getFB_f();
    gr_complex* getFB_grc();
    fftwf_complex* getFB_fftwfc();

    float* get125KB_f(int);
    gr_complex* get125KB_grc(int);
    fftwf_complex* get125KB_fftwfc(int);


    float* get250KB_f(int);
    gr_complex* get250KB_grc(int);
    fftwf_complex* get250KB_fftwfc(int);

    void addNoise(double);
    void addNoiseToBB(int);
    void addNoiseToFB();
    void addNoiseToFB(double);

    void addNoise(int);

    int size125K_f();
    int size125K_grc();
    int size125K_fftw();

    int size250K_f();
    int size250K_grc();
    int size250K_fftw();

    int size10MF_f();
    int size10MF_grc();
    int size10MF_fftw();

    int size10MB_f();
    int size10MB_grc();
    int size10MB_fftw();

    void erase_f(int);
    void erase_grc(int);
    void erase_fftwf(int);

    void cleanFB();
    void cleanBB();
    void clean125KB();
    void clean250KB();

    std::vector<gr_complex>* getVec250KGRC(int);

    gr_complex* noiseArray;
    uint8_t* noiseArrayB;

    float noise[NOISE_LEN*2 + BLN*2];
    int noisePtr = 0;
private:
    std::vector<float> b10MF;
    std::vector<uint8_t> b10MB;

    std::vector<float> b125KF[CHANNELS];
    std::vector<gr_complex>* b250KGRC;

    fftwf_complex table[CHANNELS][256];
    float B2[320*2];

    uint64_t* fakeIn;
    uint64_t** fakeTable;

    fftwf_complex* in = nullptr;
    fftwf_complex* out = nullptr;
    fftwf_plan p;
    fftwf_plan dp;

    void generateNoise();
    void generateTable();
    uint8_t inline getFrameFromBB(int fr);
};

#endif

#endif // SUPERBUFFER_H
