#ifndef CLIENT_H
#define CLIENT_H

#include <QObject>
#include <QTcpServer>
#include <QTimer>
#include <QTcpSocket>
#include <QMap>
#include <QSettings>
#include <fftw3.h>

#include "zlib/zlib.h"

#ifdef USE_LORA
#include "modules/LoraWAN/LoraDemodulator.h"
#endif

#include "modules/NBFi/NBFi_demodulator.h"
//#include "ttn/ttngatewayconnector.h"
#include "recorder.h"

//#include "client.h"
//#include "GNU_UDP_client.hpp"
//#include "fdacoefs.h"
#include "superbuffer.h"

class Client : public QObject
{

    Q_OBJECT
public:
    //explicit Client(QTcpSocket* client, TTNGatewayConnector* _ttn, QObject *parent = nullptr);
    explicit Client(QTcpSocket* client, QObject *parent = nullptr);
    ~Client();

    void init125Kbuffers();
#ifdef USE_LORA
    void init10Mbuffers();
    void getSubChanFrame(int ch);
    void getSubChannelsFrame();
    void getSubChannelsFrames();

    void bitsToFrames();
    uint8_t getFrame(int);
    void generateTable();
    void fakeingData();
    void getSubChannelsFramesFrom10M();
    void fft();
    void filtrChannel(int ch);
#endif
    QTcpSocket* soc;
    QSettings *pSettings;

    //QMutex* dem_mutex;
    //Recorder* recorder;
    NBFiDemodulator* demodulator;

    //OpenUNBDemodulator* openUNBDem;
#ifdef USE_LORA
    mainDecoder* mdec;

    uint8_t*  buff10M = nullptr;
    gr_complex*  buff10M_F = nullptr;
    gr_complex** subBuffers = nullptr;
    SuperBuffer* sb;
#else
    typedef std::complex< float > gr_complex;
#endif
    //TTNGatewayConnector* ttn;

    QDateTime processing_timer;
    QByteArray readData;

    char buff[10*sizeof(qint16)*FRAMELEN];
    float max = 1;
    char divBuff[sizeof(buff)];
    int buffIndex = 0;
    int divBuffIndex = 0;


    int inBuffCount = 0;
    int escCounter = 0;


    float table[80][32];
    float tableF[80];


    int uplink_freq;/*
    udp_client* udp1234;
    udp_client* udp1235;
    udp_client* udp1233;*/

    unsigned long freq = 868100000;
signals:

public slots:
};

#endif // CLIENT_H
