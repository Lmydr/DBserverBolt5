#include "fifofer.h"

char FIFOfer::buff[1024];
int FIFOfer::dfifo;

FIFOfer::FIFOfer() {

}

 void FIFOfer::init(int port) {
    std::string file("/tmp/server/server" + std::to_string(port));

    printf("%s\n", file.data());

    if((FIFOfer::dfifo = open(file.data(), O_RDWR)) == -1){
        perror("open(..) error:");
        return;
    }

}

 void FIFOfer::writeTo() {
    //write(dfifo, buff, strlen(buff));
    write(dfifo, "buff", 5);
}

 int FIFOfer::readFrom() {
     memset(buff, 0, sizeof(buff));
     return read(dfifo, buff, sizeof(buff));
 }
