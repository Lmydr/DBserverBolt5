#ifndef LOGGER_H
#define LOGGER_H

#include <fstream>
#include <chrono>
#include <iostream>
#include <mutex>

#define US2US(x) ((x)%1000)
#define US2MS(x) ((x/1000)%1000)
#define US2S(x)  ((x/1000000)%1000)


class DEFiusLogger {
private:
    std::fstream file;
    static std::fstream* static_file;
    std::string filename;
    static long long startTime;
    std::mutex m;

public:
    DEFiusLogger(std::string filename);
    DEFiusLogger();

    template<class T>
    DEFiusLogger& operator<<(const T &msg) {
        //m.lock();
        file.open(filename, std::ios_base::app);

        const auto p1 = std::chrono::high_resolution_clock::now();

        long long time = std::chrono::duration_cast<std::chrono::microseconds>(
                           std::chrono::high_resolution_clock::now().time_since_epoch()).count() - startTime;

        *static_file << msg;

        file.close();
        //m.unlock();
        return *this;
    }

    static void save();
    static void setStaticLogFile(std::string filename);
    static void initStartTime();
    static void out();
    static void close();

    ~DEFiusLogger();
};

#endif // LOGGER_H
