#include "client.h"

/*
Client::Client(QTcpSocket* client, TTNGatewayConnector* _ttn,QObject *parent) : QObject(parent)
{
    ttn = _ttn;
    demodulator = new NBFiDemodulator();
    soc = client;

    std::string IP = "localhost";

//    udp1233 = new udp_client(IP ,1233);
//    udp1234 = new udp_client(IP ,1234);
//    udp1235 = new udp_client(IP ,1235);

#ifdef USE_LORA
    sb = new SuperBuffer();
    mdec = new mainDecoder[CHANNELS];

    for (int i=0; i < CHANNELS; i++) {
        if (i<CHANNELS/2) {
            mdec[i].setFreq(freq + 125000*i);
        }
        else {
            mdec[i].setFreq(freq + 125000*(i - CHANNELS/2 - 5000000));
        }
        mdec[i].buff.setVec(sb->getVec250KGRC(i));
    }
#endif
}
*/

Client::Client(QTcpSocket* client, QObject *parent) : QObject(parent)
{
    //ttn = _ttn;
    demodulator = new NBFiDemodulator();
    soc = client;

    std::string IP = "localhost";

//    udp1233 = new udp_client(IP ,1233);
//    udp1234 = new udp_client(IP ,1234);
//    udp1235 = new udp_client(IP ,1235);

#ifdef USE_LORA
    sb = new SuperBuffer();
    mdec = new mainDecoder[CHANNELS];

    for (int i=0; i < CHANNELS; i++) {
        if (i<CHANNELS/2) {
            mdec[i].setFreq(freq + 125000*i);
        }
        else {
            mdec[i].setFreq(freq + 125000*(i - CHANNELS/2 - 5000000));
        }
        mdec[i].buff.setVec(sb->getVec250KGRC(i));
    }
#endif
}

Client::~Client() {
    //delete recorder;
    delete demodulator;/*
    delete udp1234;
    delete udp1233;
    delete udp1235;*/
#ifdef USE_LORA
    delete [] mdec;
    delete sb;
#endif
    delete soc;
    delete pSettings;
#ifdef USE_LORA
    if (buff10M) {
        delete [] buff10M;
        delete [] buff10M_F;
        for (int i=0; i<80; i++) {
            delete [] subBuffers[i];
        }
        delete [] subBuffers;

    }
#endif
}

#ifdef USE_LORA
void Client::init10Mbuffers() {

    buff10M = new uint8_t[FRAMELEN10M/4 + 10];
    buff10M_F = new gr_complex[FRAMELEN10M];
    subBuffers = new gr_complex*[CHANNELS];

    for (int i=0; i<80; i++) {
        subBuffers[i] = new gr_complex[FRAMELEN10M/CHANNELS];
    }
}

void Client::getSubChanFrame(int ch) {
    for (int i=0; i<FRAMELEN10M/4; i+= 80*4) {
        uint8_t iB=0;
        uint8_t qB=0;
        uint8_t fB=0;

        for (int ch=0; ch<80; ch++) {
            for (int k=0; k<4; k++) {
                fB = getFrame(i + ch + k*80);
                iB = iB<<1 | (fB & 1);
                qB = qB<<1 | (fB>>1 & 1);
            }
            subBuffers[ch][i/(80*4) * 2] = table[ch][iB];
            subBuffers[ch][i/(80*4) * 2 + 1] = table[ch][qB];
        }
        //subBuffers[i%80][i/80] = table[i%80][(buff10M[i]) & 0b1111];
        //subBuffers[i%80][i/80+1] = table[i%80][(buff10M[i]>>4) & 0b1111];
    }
}

void Client::bitsToFrames() {
    for (int i=0; i<FRAMELEN10M/4; i++) {
        for (int b=0; b<8; b++) {
            if ((buff10M[i] >> (b)) & 1)
                ((float*)buff10M_F)[i*8 + b] = -1.0;
            else {
                ((float*)buff10M_F)[i*8 + b] = 1.0;
            }
        }
    }
}

uint8_t Client::getFrame(int n) {
    return (buff10M[n/4] >> (2*(n%4))) & 0b11;
}

void Client::getSubChannelsFrames() {
    for (int i=0; i<FRAMELEN10M/4; i+= 80*4) {
        uint8_t iB=0;
        uint8_t qB=0;
        uint8_t fB=0;

        for (int ch=0; ch<80; ch++) {
            for (int k=0; k<4; k++) {
                fB = getFrame(i + ch + k*80);
                iB = iB<<1 | (fB & 1);
                qB = qB<<1 | (fB>>1 & 1);
            }
            subBuffers[ch][i/(80*4) * 2] = table[ch][iB];
            subBuffers[ch][i/(80*4) * 2 + 1] = table[ch][qB];
        }
        //subBuffers[i%80][i/80] = table[i%80][(buff10M[i]) & 0b1111];
        //subBuffers[i%80][i/80+1] = table[i%80][(buff10M[i]>>4) & 0b1111];
    }
}

void Client::generateTable() {
    for (int ch=0; ch<80; ch++) {
        float subSum = 0;

        for (int i=0; i<4; i++) {
            subSum += B[i*80+ch];
        }

        tableF[ch] = subSum;

        for (int i=0; i<=0b1111; i++) {
            float sum = 0;
            for (int j=0; j<4; j++) {
                if ((i>>j) & 1) {
                    sum -= subSum;
                }
                else {
                    sum += subSum;
                }
            }
            table[ch][i] = sum;
        }

    }
}
#endif
