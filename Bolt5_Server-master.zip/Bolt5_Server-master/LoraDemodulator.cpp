/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   mainDecoder.cpp
 * Author: DEF
 * 
 * Created on 29 мая 2019 г., 15:16
 */

#include "LoraDemodulator.h"

mainDecoder::mainDecoder() {
    //ttn = new TTNGatewayConnector("defius", "ttn-account-v2.ep0mludPutERt34LGYkCw_0gaIwG2S19o9z_S2f8WaEryAOtbg_qbIfqfxQg8A2PR9TagDFH3q6g764bo32xAA");
}

mainDecoder::~mainDecoder() {

}

void mainDecoder::loraInit(std::string name, std::string key) {
    ttn = new TTNGatewayConnector(name, key);
    loradec = new gr::lora::decoder_impl(125000,125000,7,false,4,true,false,false);
}

void mainDecoder::loraTestInit() {
    ttn = new TTNGatewayConnector("defius", "ttn-account-v2.ep0mludPutERt34LGYkCw_0gaIwG2S19o9z_S2f8WaEryAOtbg_qbIfqfxQg8A2PR9TagDFH3q6g764bo32xAA");
    loradec = new gr::lora::decoder_impl(125000,125000,7,false,4,true,false,false);
}

void mainDecoder::run() {
    printf("in1 %d\n", buff.size());
    while (buff.isAvailable()) {
	//printf("%d\n", loradec->d_state);
        void* lastptr = buff.dataToWork();
        void* dataptr = buff.data();
        buff.ptr += loradec->work((gr_complex*)buff.dataToWork());
    }
    buff.clean();
    printf("in2 %d\n", buff.size());
    if (loradec->msg) {
        loradec-> msg = false;
        if (loradec->lastMsgSize > 5) {
            printf("Send to TTN\n");
            ttn->send(loradec->lastMsg+3, loradec->lastMsgSize - 5);
        }
    }
    //printf("in f\n");
}

void mainDecoder::msgDecoded_cb(char *data, int size) {
    ttn->send(data, size);
}
