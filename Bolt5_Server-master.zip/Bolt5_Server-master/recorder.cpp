#include "defines.h"
#include "recorder.h"
#include <QTime>
#include <QSettings>



Recorder::Recorder(QObject *parent) : QObject(parent)
{
    for(uint i = 0; i != THREADS; i++)
    {
        batches[i] = 0;
    }

}

void Recorder::getFromTCP(qint16* capture_buffer, unsigned int capture_size) {
    if ((batches[0]->subbatch >= 0) && (batches[0]->subbatch < batches[0]->batchlen)) {
        for (uint i = 0; i < FRAMELEN; i++) {
            std::complex<float> tmp((float)capture_buffer[i * 2], (float)capture_buffer[i * 2 + 1]);
            batches[0]->I_Q[batches[0]->pointer/2] = tmp;

            batches[0]->zeroF_I_Q[batches[0]->pointer++] = capture_buffer[i * 2];
            batches[0]->zeroF_I_Q[batches[0]->pointer++] = capture_buffer[i * 2 + 1];
        }

        if (batches[0]->pointer >= 2*FRAMELEN*batches[0]->batchlen){
            emit I_Q_isready1(batches[0]->zeroF_I_Q, batches[0]->pointer / 2);
            batches[0]->pointer = 0;
        }

    }
    if (++batches[0]->subbatch == batches[0]->period)
        batches[0]->subbatch = 0;


}


void Recorder::addBatch(Batch * b, uint thread)
{
    batches[thread] = b;
}


Recorder::~Recorder()
{

    //for(uint i = 0; i!= THREADS; i++)  delete zeroF_I_Q[i];
    //delete zeroF_I_Q2;

}




