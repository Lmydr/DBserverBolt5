#ifndef RECIVER_H
#define RECIVER_H

#include <QObject>
#include <QTcpServer>
#include <QUdpSocket>
#include <QTimer>
#include <QTime>
#include <QTcpSocket>
#include <QMap>
#include <QSettings>
#include <vector>
#include <iostream>

#include "client.h"
#include "fifofer.h"
#include "udp_clients.h"

#include "modules/OpenUNB/include/openunb.h"

#define deflateX2

#define UPDATE_P_SEC 1//0.25

//#define USE_OUTPUT

class Reciever : QObject
{
    Q_OBJECT
private:
#ifndef USE_LORA
    typedef std::complex< float > gr_complex;
#endif

    //TTNGatewayConnector* ttn;
    QTcpServer* server;
    QUdpSocket* udp;
    QHostAddress *address;
    Client* client = nullptr;
    QIODevice* fifo;

    QTcpServer* dashboardServer;
    QTcpSocket* dashboardClient;
    int dashboard_port;

    enum reques_t {
        REQ_ECHO = 1,
        REQ_TEST = 2,
        REQ_SPEED = 4,
        REQ_STATUS = 8,
	REQ_MSG_CNT = 16,
        REQ_MEM = 32,
        REQ_CPU = 64,
        REQ_ALL_DATA = 3,
    };


    struct dashboard_data_t {
        uint64_t speed;
        double   CPU;
        uint64_t mem;
        uint64_t dec_count;
    };

    //QSettings *pSettings;
    //QMutex dem_mutex;
    char tmpb[8];
    int dptr = 0;

    QDateTime processing_timer;
    QByteArray readData;

    int uplink_freq;

    QTimer* dataPSecTimer;
    QTimer* cleanerTimer;
    QTimer* averageSpeedTimer;
    int dataPSec = 0;

    unsigned long msgCount = 0;
    unsigned long batches = 0;
    unsigned long connections = 0;
    unsigned long totalByteResieved = 0;

    unsigned long long averageSpeed = 0;
    unsigned int averageSpeedCount = 0;
    unsigned long long lastAvgSpeed = 0;
    unsigned long long avgDataRate = 0;
    unsigned long long lastAvgDataRate = 0;
    double lastCPU;

    int port;
    std::string ttnName;
    std::string ttnKey;

    std::string folder;
public:
    enum status_t {
        ERROR = -1,
        WAITING = 0,
        RUNING = 1
    } serverStatus;

    enum device_t{
        RTLSDR = 0,
        LimeSDR = 1,
        GNURadio = 2
    } device;

    Reciever();
    Reciever(int, std::string, std::string, std::string);

private:
    void loopFromFile(QString);
    void initTTN(std::string name, std::string key);

public slots:
    void timeout();
    void AFKCleaner();
    void saveAverageSpeed();
    void onNewConnection();
    void onDisconnection();
    void onDashboradConnected();
    void getRequest();
    void getData();
    void getUDPData();
    void getFirstData();
    void updateRTLData();
#ifdef USE_LORA
    void updateLimeData(uint8_t* arr, int size);
    void updateGNURData(gr_complex* arr, int size);
#endif
    void set_messages(NBFiDemodulator *dem);
};

#endif // RECIVER_H
